/**
 * 
 */
package com.aps.testcases;

import java.io.IOException;
import java.util.Iterator;
import java.util.ResourceBundle;
import java.util.concurrent.TimeUnit;
import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.sikuli.script.FindFailed;
import org.sikuli.script.Pattern;
import org.sikuli.script.Screen;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

/**
 * @author AppPortal
 *
 */
public class ExecuteTestCases_Sikuli {

	WebDriver driver;

	// @BeforeSuite
	@Test
	public void baseSetUp() throws InterruptedException, IOException, AWTException, FindFailed {

		Screen scrn = new Screen();
		
		Pattern iUserName = new Pattern(System.getProperty("user.dir")+"\\Images\\UserName.PNG");
		Pattern iPassword = new Pattern(System.getProperty("user.dir")+"\\Images\\Password.PNG");
		Pattern iSignIn = new Pattern(System.getProperty("user.dir")+"\\Images\\SignIn.PNG");
		
		WebDriverManager.chromedriver().setup();
		
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.manage().timeouts().setScriptTimeout(30, TimeUnit.SECONDS);
		
		// 1st URL
		String strURL = "http://10.75.204.205/esd";
		
		Thread.sleep(2000);
		driver.get(strURL);
		Thread.sleep(4000);
		
		scrn.wait(iUserName, 5);
		scrn.type(iUserName, "appportal\\appportal");
		scrn.type(iPassword, "Flexera!");
		scrn.click(iSignIn);
		
		String title = driver.getTitle();
		
		System.out.println("The page title is: " + title);
		
		Thread.sleep(5000);
	}
}
