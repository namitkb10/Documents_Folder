/**
 * 
 */
package com.aps.testcases;

import java.io.IOException;
import java.util.Iterator;
import java.util.ResourceBundle;
import java.util.concurrent.TimeUnit;
import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

/**
 * @author AppPortal
 *
 */
public class ExecuteTestCases_RobotClass {

	WebDriver driver;

	// @BeforeSuite
	@Test
	public void baseSetUp() throws InterruptedException, IOException, AWTException {

		WebDriverManager.chromedriver().setup();
		// ChromeOptions options = new ChromeOptions();
		// options.addArguments("--remote-allow-origins=*");
		// driver = new ChromeDriver(options);
		
		driver = new ChromeDriver();

		driver.manage().window().maximize();
		driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.manage().timeouts().setScriptTimeout(30, TimeUnit.SECONDS);

		Thread.sleep(4000);
		
		// 1st URL
		String strURL = "http://10.75.204.205/esd";
		//Runtime.getRuntime().exec("C:\\AutoIT\\Login_App_Portal\\AutoIT_AppPortal_Login.exe");
		
		Thread.sleep(2000);
		driver.get(strURL);
		Thread.sleep(2000);
		
		Robot robot = new Robot();
		
		//typing text in text box one by one
		robot.keyPress(KeyEvent.VK_A);
		robot.keyRelease(KeyEvent.VK_P);
		Thread.sleep(1000);
		for (int i = 0; i <=2; i++) {
			robot.keyPress(KeyEvent.VK_P);
			Thread.sleep(1000);
		}
		robot.keyPress(KeyEvent.VK_O);
		robot.keyPress(KeyEvent.VK_R);
		robot.keyPress(KeyEvent.VK_T);
		robot.keyPress(KeyEvent.VK_A);
		robot.keyPress(KeyEvent.VK_L);
		robot.keyPress(KeyEvent.VK_BACK_SLASH);
		//======================================================
		robot.keyPress(KeyEvent.VK_A);
		robot.keyRelease(KeyEvent.VK_P);
		Thread.sleep(1000);
		for (int i = 0; i <=2; i++) {
			robot.keyPress(KeyEvent.VK_P);
			Thread.sleep(1000);
		}
		robot.keyPress(KeyEvent.VK_O);
		robot.keyPress(KeyEvent.VK_R);
		robot.keyPress(KeyEvent.VK_T);
		robot.keyPress(KeyEvent.VK_A);
		robot.keyPress(KeyEvent.VK_L);
		Thread.sleep(1000);
		
		robot.keyPress(KeyEvent.VK_TAB);
		
		robot.keyPress(KeyEvent.VK_F);
		robot.keyPress(KeyEvent.VK_L);
		robot.keyPress(KeyEvent.VK_E);
		robot.keyPress(KeyEvent.VK_X);
		robot.keyPress(KeyEvent.VK_E);
		robot.keyPress(KeyEvent.VK_R);
		robot.keyPress(KeyEvent.VK_A);
		//robot.keyPress(KeyEvent.VK_EXCLAMATION_MARK);
		
		Thread.sleep(5000);
		
		robot.keyPress(KeyEvent.VK_TAB);
		
		Thread.sleep(2000);
		
		robot.keyPress(KeyEvent.VK_ENTER);
		 
		// robot.keyRelease(KeyEvent.VK_A);
		// robot.keyRelease(KeyEvent.VK_D);
		// robot.keyRelease(KeyEvent.VK_M);
		// robot.keyRelease(KeyEvent.VK_I);
		// robot.keyRelease(KeyEvent.VK_N);
		
		String title = driver.getTitle();
		
		System.out.println("The page title is: " + title);
		
		Thread.sleep(5000);
	}
}
