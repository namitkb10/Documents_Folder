/**
 * 
 */
package com.aps.testcases;

import java.io.IOException;
import java.util.Iterator;
import java.util.ResourceBundle;
import java.util.concurrent.TimeUnit;
import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

/**
 * @author AppPortal
 *
 */
public class ExecuteTestCases_AutoIT {

	WebDriver driver;

	// @BeforeSuite
	@Test
	public void baseSetUp() throws InterruptedException, IOException, AWTException {

		WebDriverManager.chromedriver().setup();
		// ChromeOptions options = new ChromeOptions();
		// options.addArguments("--remote-allow-origins=*");
		// driver = new ChromeDriver(options);
		
		driver = new ChromeDriver();

		driver.manage().window().maximize();
		driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.manage().timeouts().setScriptTimeout(30, TimeUnit.SECONDS);

		Thread.sleep(4000);
		
		// 1st URL
		// String strURL = "http://10.75.204.205/esd";
		// Runtime.getRuntime().exec("C:\\AutoIT\\Login_App_Portal\\AutoIT_AppPortal_Login.exe");
		
		// 2nd URL
		String strURL = "https://the-internet.herokuapp.com/basic_auth";
		Runtime.getRuntime().exec("C:\\AutoIT\\Login_App_Portal\\AutoIT_AppPortal_LoginBasic.exe");
		
		Thread.sleep(2000);
		// System.out.println("Created URL is: " + strURL);
		driver.get(strURL);
		Thread.sleep(2000);
		
		String title = driver.getTitle();
		
		System.out.println("The page title is: " + title);
		
	}
}
