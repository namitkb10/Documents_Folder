﻿using OpenQA.Selenium;
using System.Text;

namespace AppPortalFlexera.Framework
{
    public class CaptureManager
    {
        public static string OutputFolder = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "FailedTests");

        private readonly IWebDriver _webDriver;

        public CaptureManager(IWebDriver webDriver)
        {
            _webDriver = webDriver;
        }
        public void CaptureScreenshotAndPageSourceUponFailure()
        {
            if (ScenarioContext.Current.TestError != null)
            {
                string title = GenerateFileTitle();
                CaptureScreenshot(title);
                CapturePageSource(title);
            }
        }
        public string GenerateFileTitle()
        {
            return ScenarioContext.Current.ScenarioInfo.Title.Replace('\'', '_').Replace(' ', '_').Replace('.', '_') + DateTime.Now.ToString().Replace(':', '_').Replace(' ', '_').Replace('/', '_');
        }
        private void CaptureScreenshot(string fileName = null)
        {
            var camera = (ITakesScreenshot)_webDriver;
            var screenshot = camera.GetScreenshot();

            var screenShotPath = GetOutputFilePath(fileName + ".png", "png");
            screenshot.SaveAsFile(screenShotPath, ScreenshotImageFormat.Png);
        }

        private void CapturePageSource(string fileName = null)
        {
            var filePath = GetOutputFilePath(fileName + ".txt", "txt");
            File.WriteAllText(filePath, _webDriver.PageSource);
        }

        private string GetOutputFilePath(string fileName, string fileExtension)
        {
            if (!Directory.Exists(OutputFolder))
                Directory.CreateDirectory(OutputFolder);

            var windowTitle = _webDriver.Title;
            fileName = fileName ??
                       string.Format("{0}{1}.{2}", windowTitle, DateTime.Now.ToFileTime(), fileExtension).Replace(':', '.');
            var outputPath = Path.Combine(OutputFolder, fileName);
            var pathChars = Path.GetInvalidPathChars();
            var stringBuilder = new StringBuilder(outputPath);

            foreach (var item in pathChars)
                stringBuilder.Replace(item, '.');

            var screenShotPath = stringBuilder.ToString();
            return screenShotPath;
        }
    }
}

