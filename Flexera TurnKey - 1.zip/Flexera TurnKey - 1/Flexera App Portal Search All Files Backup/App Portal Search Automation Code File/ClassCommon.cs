﻿using Gherkin.CucumberMessages.Types;
using LivingDoc.Dtos;
using NUnit.Framework.Interfaces;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppPortalFlexera.CommonClass
{
    public class ClassCommon
    {       
        public string getDataFromFile(string abc)
        {
            bool flag = false;
            string fileName = @"C:\Users\AppPortal\source\repos\AppPortalSearch_Automation_MM_25_July_GIT\SpecFlowBDD_22\TestData\testdatafile.txt";

        var dataFile = File.ReadAllLines(fileName);
            String dataReturn = "";
            foreach (var row1 in dataFile)
            {
                flag = false;
                String[] strArr = row1.Split('=');
                if (strArr[0] == abc)
                {
                    flag = true;
                    dataReturn = strArr[1];
                }
                if (flag == true)
                {
                    break;
                }
            }
            if (flag == false)
            {
                Console.WriteLine("Please enter valid key to get value");
            }
            return dataReturn;
        }
        
    }
}
