﻿using OpenQA.Selenium;
using AppPortalFlexera.Framework;
using AppPortalFlexera.Pages;
using NUnit.Framework;

namespace AppPortalFlexera.StepDefinitions
{
    [Binding]
    public sealed class RQ01_AbilityToEnableAdvanceSearchAtTheGlobalLevelSteps
    {       
        AppPortalPages appPortalPages = new AppPortalPages();      
        ActionManager action = new ActionManager();
        WaitManager wait = new WaitManager();     

        [Given(@"admin user is logged into the app portal")]
        public void GivenAdminUserIsLoggedIntoTheAppPortal()
        {
            Console.WriteLine("Login is completed");
            wait.UntilIsElementIsDisplayed(By.XPath("//span[contains(text(),'Welcome App Portal')]"));
            AssertionManager.Displayed(appPortalPages.Text_WelcomeTitle);

        }

        [When(@"user navigate to the Catalog Behavior Page\(Admin >> Site Management >> Settings >> Web Site >> Catalog Behavior Page\)")]
        public void WhenUserNavigateToTheCatalogBehaviorPageAdminSiteManagementSettingsWebSiteCatalogBehaviorPage()
        {
            wait.UntilIsElementIsNotDisplayed(By.XPath("//img[@id='ajax-load-indicator']"));
            Thread.Sleep(1000);
            HooksManager.driver.SwitchTo().DefaultContent();
            action.Click(appPortalPages.Tab_Admin);
            IWebElement element = HooksManager.driver.FindElement(By.Id("tnSiteConfiguration"));
            string value= element.GetAttribute("class");
            if (!value.Contains("rpExpanded"))
            {
                wait.UntilIsElementIsClickable(appPortalPages.Tab_SiteManagement);
                action.Click(appPortalPages.Tab_SiteManagement);
                IWebElement element1 = HooksManager.driver.FindElement(By.Id("nodeSettings"));
                string value1 = element1.GetAttribute("class");
                if (!value1.Contains("rpExpanded"))
                {
                    action.Click(appPortalPages.Tab_Settings);
                }
            }
            //AssertionManager.Displayed(appPortalPages.Tab_WebSite);
            action.Click(appPortalPages.Tab_WebSite);
            action.SwitchToFrame(appPortalPages.Tab_Frame);
            Console.WriteLine("Switched to Frame");
            wait.UntilElementIsEnabled(appPortalPages.Tab_CatalogBehaviour);
            action.Click(appPortalPages.Tab_CatalogBehaviour);
            IJavaScriptExecutor jse = (IJavaScriptExecutor)HooksManager.driver;
            jse.ExecuteScript("window.scrollBy(0,450)", "");
        }

        [Then(@"the page should display Enable advance search options checkbox")]
        public void ThenThePageShouldDisplayEnableAdvanceSearchOptionsCheckbox()
        {
            //IJavaScriptExecutor jse = (IJavaScriptExecutor)HooksManager.HooksManager.driver;
            //jse.ExecuteScript("window.scrollBy(0,450)", "");

            AssertionManager.Displayed(appPortalPages.CheckBox_EnableAdvanceSearchOptions);
            Console.WriteLine("Display Enable advance search options checkbox");           
        }

        [Then(@"“Enable advance search options” check box should be checked\(by default\)")]
        public void ThenEnableAdvanceSearchOptionsCheckBoxShouldBeCheckedByDefault()
        {
            if (!appPortalPages.CheckBox_EnableAdvanceSearchOptions.Selected)
            {
                action.Click(appPortalPages.CheckBox_EnableAdvanceSearchOptions);
                Console.WriteLine("Enable advance search options checkbox is Default Checked");
            }
        }

        [When(@"user uncheck the “Enable advance search options” checkbox")]
        public void WhenUserUncheckTheEnableAdvanceSearchOptionsCheckbox()
        {
            if (appPortalPages.CheckBox_EnableAdvanceSearchOptions.Selected)
            {
                action.Click(appPortalPages.CheckBox_EnableAdvanceSearchOptions);
                Console.WriteLine("Enable advance search options checkbox is unchecked");
            }
        }

        [Then(@"“Enable advance search options” checkbox should be displayed as unchecked")]
        public void ThenEnableAdvanceSearchOptionsCheckboxShouldBeDisplayedAsUnchecked()
        {
            AssertionManager.UnChecked(appPortalPages.CheckBox_EnableAdvanceSearchOptions);
            Console.WriteLine("Enable advance search options checkbox is unchecked");
        }

        [Then(@"Enable advance search options checkbox should be displayed as checked")]
        public void ThenEnableAdvanceSearchOptionsCheckboxShouldBeDisplayedAsChecked()
        {
            AssertionManager.Checked(appPortalPages.CheckBox_EnableAdvanceSearchOptions);
        }
    }
}
