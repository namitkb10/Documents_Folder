﻿using OpenQA.Selenium;
using AppPortalFlexera.Framework;
using AppPortalFlexera.Pages;
using AventStack.ExtentReports.Gherkin.Model;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using AppPortalFlexera.CommonClass;
using NUnit.Framework;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Edge;
using OpenQA.Selenium.Firefox;
using WebDriverManager.DriverConfigs.Impl;
using WindowsInput.Native;
using WindowsInput;
using AventStack.ExtentReports.Utils;
using OpenQA.Selenium.Support.UI;
using SeleniumExtras.WaitHelpers;
using AngleSharp.Dom;
using AventStack.ExtentReports.Reporter.Configuration;
using NUnit.Framework.Internal;
using System.Text.RegularExpressions;

namespace AppPortalFlexera.StepDefinitions
{
    [Binding]
    public class RQ04_ApplyFuzzyLogicDuringSearchingTheCatalogItemStepsSteps
    {
        AppPortalPages appPortalPages = new AppPortalPages();
        ActionManager action = new ActionManager();
        IWebDriver driverRQ04 = null;
        WaitManager wait = new WaitManager();
        public static string suggestionValue = string.Empty;
        public static ClassCommon cc = new ClassCommon();
        static ClassCommon classcommon = new ClassCommon();
        List<string> classificationList = new List<string>();
        List<string> lstString = new List<string>();


        IList<IWebElement> lstWebElement = new List<IWebElement>();
        List<string> sqlSuggestionList = new List<string>();
        string query;


        [When(@"user provide the data related to the ""([^""]*)"" from the app portal application")]
        public void WhenUserProvideTheDataRelatedToTheFromTheAppPortalApplication(string searchTerm)
        {
            switch (searchTerm)
            {
                case "Title":
                    action.Clear(appPortalPages.TextBox_InputMainSearchCatalog);
                    action.SendKeys(appPortalPages.TextBox_InputMainSearchCatalog,RQ03_AbilityToSearchUsingTheConfiguredSearchAttributesSteps.title);
                    break;
                case "Full description":
                    action.Clear(appPortalPages.TextBox_InputMainSearchCatalog);
                    action.SendKeys(appPortalPages.TextBox_InputMainSearchCatalog, RQ03_AbilityToSearchUsingTheConfiguredSearchAttributesSteps.fullDescription);
                    break;
                case "Brief description":
                    action.Clear(appPortalPages.TextBox_InputMainSearchCatalog);
                    action.SendKeys(appPortalPages.TextBox_InputMainSearchCatalog, RQ03_AbilityToSearchUsingTheConfiguredSearchAttributesSteps.briefDescription);
                    break;
                case "Keyword":
                    action.Clear(appPortalPages.TextBox_InputMainSearchCatalog);
                    action.SendKeys(appPortalPages.TextBox_InputMainSearchCatalog, RQ03_AbilityToSearchUsingTheConfiguredSearchAttributesSteps.keyword);
                    break;
            }
        }

        [Then(@"system should display the search suggestions on the app portal page")]
        public void ThenSystemShouldDisplayTheSearchSuggestionsOnTheAppPortalPage()
        {
            Thread.Sleep(2000);
            // action.Click(appPortalPages.TextBox_InputMainSearchCatalog);
            wait.UntilIsElementIsNotDisplayed(By.XPath("//img[@id='ajax-load-indicator']"));
            IList<IWebElement> suggestionList = HooksManager.driver.FindElements(By.XPath("//ul[@role='listbox']/child::li"));
            if (suggestionList.Count > 0)
            {
                foreach (IWebElement suggestion in suggestionList)
                {
                    Console.WriteLine(suggestion.Text);
                }
            }
            else
            {
                throw new Exception(string.Format("Auto Search Suggestions are not displayed"));
            }
        }

        [Then(@"system should display max (.*) search list suggestions")]
        public void ThenSystemShouldDisplayMaxSearchListSuggestions(int suggestionCount)
        {
            IList<IWebElement> suggestionList = HooksManager.driver.FindElements(By.XPath("//ul[@role='listbox']/child::li[@class='ui-menu-item']"));
            if (suggestionList.Count > suggestionCount)
            {
                throw new Exception(string.Format("Total list count is " + suggestionList.Count + ", Where as Suggestions List Count Should not display more than 10"));
            }
            
        }

        [Then(@"system should display zero search list suggestions")]
        public void ThenSystemShouldDisplayZeroSearchListSuggestions()
        {
            IList<IWebElement> suggestionList = HooksManager.driver.FindElements(By.XPath("//ul[@role='listbox']/child::li[@class='ui-menu-item']"));
            if (suggestionList.Count.ToString() != "0")
            {
               throw new Exception(string.Format("Total list count is " + suggestionList.Count + ", Where as Suggestions List Count Should be zero"));
            }
        }

        [When(@"user search by provided keyword suggestion, which is selected from the list of displayed search keyword suggestions")]
        public void WhenUserSearchByProvidedKeywordSuggestionWhichIsSelectedFromTheListOfDisplayedSearchKeywordSuggestions()
        {
            Thread.Sleep(3000);
            IList<IWebElement> suggestionList = HooksManager.driver.FindElements(By.XPath("//ul[@role='listbox']/child::li[@class='ui-menu-item']"));

            if (suggestionList.Count > 0)
            {
                for (int i = 0; i < suggestionList.Count; i++)
                {
                    IList<IWebElement> suggestionList1 = HooksManager.driver.FindElements(By.XPath("//ul[@role='listbox']/li/a"));
                    // IList<IWebElement> suggestionList1 = HooksManager.driver.FindElements(By.XPath("//ul[@role='listbox']/li/a[" + i + "]"));
                    // IList<IWebElement> suggestionList1 = HooksManager.driver.FindElements(By.XPath("//ul[@role='listbox']/child::li[" + i + "]"));
                    suggestionValue = suggestionList1[i].Text.ToString().Trim();
                    if (suggestionValue.Equals(RQ03_AbilityToSearchUsingTheConfiguredSearchAttributesSteps.title))
                    {
                        suggestionList1[i].Click();
                        action.Click(appPortalPages.Button_Search);
                        break;
                    }                   
                }
            }
            else
            {
                throw new Exception(string.Format("Auto Search Suggestions are not displayed"));
            }
        }

        [Then(@"system should display the search result for the provided search suggestion option")]
        public void ThenSystemShouldDisplayTheSearchResultForTheProvidedSearchSuggestionOption()
        {

            Thread.Sleep(2000);
            wait.UntilIsElementIsNotDisplayed(By.XPath("//img[@id='ajax-load-indicator']"));
            string resultData = appPortalPages.Text_SearchResult.Text.Replace('"', ' ').Trim();

            if (RQ03_AbilityToSearchUsingTheConfiguredSearchAttributesSteps.title == resultData)
            {
                appPortalPages.VerifySearchResult();
            }
            else
            {
                throw new Exception(string.Format("Select list item not matched from displayed data"));
            }
        }

        [When(@"user provide the typo/misspelled data ""([^""]*)"" related to the ""([^""]*)"" from the app portal application")]
        public void WhenUserProvideTheTypoMisspelledDataRelatedToTheFromTheAppPortalApplication(string misspelledData, string searchTerm)
        {
            Thread.Sleep(2000);
            wait.UntilIsElementIsNotDisplayed(By.XPath("//img[@id='ajax-load-indicator']"));
            switch (searchTerm)
            {
                case "Title":
                    action.Clear(appPortalPages.TextBox_InputMainSearchCatalog);
                    action.SendKeys(appPortalPages.TextBox_InputMainSearchCatalog, misspelledData);
                    break;
                case "Full description":
                    action.Clear(appPortalPages.TextBox_InputMainSearchCatalog);
                    action.SendKeys(appPortalPages.TextBox_InputMainSearchCatalog, misspelledData);
                    break;
                case "Brief description":
                    action.Clear(appPortalPages.TextBox_InputMainSearchCatalog);
                    action.SendKeys(appPortalPages.TextBox_InputMainSearchCatalog, misspelledData);
                    break;
                case "Keyword":
                    action.Clear(appPortalPages.TextBox_InputMainSearchCatalog);
                    action.SendKeys(appPortalPages.TextBox_InputMainSearchCatalog, misspelledData);
                    break;

            }

        }
        
        [When(@"user search by any one search keyword suggestion, which is selected from the list of displayed search keyword suggestions")]
        public void WhenUserSearchByAnyOneSearchKeywordSuggestionWhichIsSelectedFromTheListOfDisplayedSearchKeywordSuggestions()
        {
            Thread.Sleep(2000);
            wait.UntilIsElementIsNotDisplayed(By.XPath("//img[@id='ajax-load-indicator']"));
            IList<IWebElement> suggestionList = HooksManager.driver.FindElements(By.XPath("//ul[@role='listbox']/child::li[@class='ui-menu-item']"));

            if (suggestionList.Count > 0)
            {
                suggestionValue = suggestionList[1].Text.ToString().Trim();
                suggestionList[1].Click();
                action.Click(appPortalPages.Button_Search);
            }
            else
            {
                throw new Exception(string.Format("Auto Search Suggestions are not displayed"));
            }
        }


        [Then(@"system should display the search result for the selected search suggestion option")]
        public void ThenSystemShouldDisplayTheSearchResultForTheSelectedSearchSuggestionOption()
        {
            Thread.Sleep(5000);
            wait.UntilIsElementIsNotDisplayed(By.XPath("//img[@id='ajax-load-indicator']"));
            string resultData = appPortalPages.Text_SearchResult.Text.Replace('"', ' ').Trim();

            if (suggestionValue == resultData)
            {
                appPortalPages.VerifySearchResult();
            }
            else
            {
                throw new Exception(string.Format("Select list item not matched from displayed data"));
            }
        }

        [When(@"user provide the data related to the ""([^""]*)"" from the app portal application ""([^""]*)""")]
        public void WhenUserProvideTheDataRelatedToTheFromTheAppPortalApplication(string searchTerm, string catalogType)
        {
            string value = "";
            switch (searchTerm)
            {
                case "Title":
                    if (catalogType == "preferred")
                    {
                        value = cc.getDataFromFile("ip_rq04_preferred");
                        action.SendKeys(appPortalPages.TextBox_InputMainSearchCatalog, cc.getDataFromFile("ip_rq04_preferred"));
                    }
                    else if (catalogType == "nonClassifed")
                    {
                        value = cc.getDataFromFile("ip_rq04_nonClassified");
                        action.SendKeys(appPortalPages.TextBox_InputMainSearchCatalog, cc.getDataFromFile("ip_rq04_nonClassified"));
                        
                    }
                    else if (catalogType == "nonPreferred")
                    {
                        value = cc.getDataFromFile("ip_rq04_nonPreferred");
                        action.SendKeys(appPortalPages.TextBox_InputMainSearchCatalog, cc.getDataFromFile("ip_rq04_nonPreferred"));
                    }
                    break;
                case "Full description":
                    if (catalogType == "preferred")
                    {
                        action.SendKeys(appPortalPages.TextBox_InputMainSearchCatalog, cc.getDataFromFile("ip_rq04_preferred"));
                    }
                    else if (catalogType == "nonClassifed")
                    {
                        action.SendKeys(appPortalPages.TextBox_InputMainSearchCatalog, cc.getDataFromFile("ip_rq04__nonClassified"));
                    }
                    else if (catalogType == "nonPreferred")
                    {
                        action.SendKeys(appPortalPages.TextBox_InputMainSearchCatalog, cc.getDataFromFile("ip_rq04_nonPreferred"));
                    }
                    break;
                case "Brief description":
                    if (catalogType == "preferred")
                    {
                        action.SendKeys(appPortalPages.TextBox_InputMainSearchCatalog, cc.getDataFromFile("ip_rq04_preferred"));
                    }
                    else if (catalogType == "nonClassifed")
                    {
                        action.SendKeys(appPortalPages.TextBox_InputMainSearchCatalog, cc.getDataFromFile("ip_rq04__nonClassified"));
                    }
                    else if (catalogType == "nonPreferred")
                    {
                        action.SendKeys(appPortalPages.TextBox_InputMainSearchCatalog, cc.getDataFromFile("ip_rq04_nonPreferred"));
                    }
                    break;
                case "Keyword":
                    if (catalogType == "preferred")
                    {
                        action.SendKeys(appPortalPages.TextBox_InputMainSearchCatalog, cc.getDataFromFile("ip_rq04_preferred"));
                    }
                    else if (catalogType == "nonClassifed")
                    {
                        action.SendKeys(appPortalPages.TextBox_InputMainSearchCatalog, cc.getDataFromFile("ip_rq04__nonClassified"));
                    }
                    else if (catalogType == "nonPreferred")
                    {
                        action.SendKeys(appPortalPages.TextBox_InputMainSearchCatalog, cc.getDataFromFile("ip_rq04_nonPreferred"));
                    }
                    break;
            }
        }

        [Then(@"system should display the search suggestions of ""([^""]*)"" items only\(related to the selected search term\)")]
        public void ThenSystemShouldDisplayTheSearchSuggestionsOfItemsOnlyRelatedToTheSelectedSearchTerm(string catalogType)
        {
            List<string> sqlSearchKeywordList = new List<string>();
            List<int> sqlclassificationSortList = new List<int>();
            if (catalogType == "preferred")
            {
                string query = "SELECT Distinct WP.PackageID, WP.CatID, WP.Deleted, WP.MemberOfGroup, WP.VisibleGroup, WP.LicenseDisable,\r\nISNULL(wpl.Title, WP.PackageTitle) AS PackageTitle, cclass.ClassificationName, cclass.ClassificationType,\r\nccm.ShowAlert, cclass.ImagePath AS ClassificationImagePath, case when cclass.ClassificationType = 0\r\nthen 0 when  cclass.ClassificationType = 1 then 2 else 1 end as ClassificationSort,\r\nISNULL(wpl.Description, WP.PackageDesc) AS PackageDesc, \r\nISNULL(wpl.BriefDescription, WP.BriefDescription) AS BriefDescription, WP.PackageVisible, WP.PackageRequest,\r\nWP.RunTime, WP.Reboots, WP.AppMethod, WP.OUInherit, WP.PackageRating, WP.PackageRank,  WP.vOUInherit,\r\nWP.GroupInherit, WP.ImagePath, WP.Type, WP.HasAlternate, WP.LicenseID_FK,l.PendingInstalls,\r\nl.LicenseCount - l.LicenseUsed AS LicenseRemaining, WP.Resource, WP.Site,   l.LicenseCount,\r\nl.LicenseUsed, l.Scope, l.Enforce, WP.ShowInventoryData, WP.AllowRental, WP.MaxRentalTime,\r\nWP.DisablePermanent, WP.AllowROB, WP.AllowRTP,  WP.AllowRTM, WP.AllowManual, WP.AllowUninstall,\r\nWP.AllowRepair, WP.VisibleShowMessage,WP.VisibleMessage, WP.ShowInventoryCostData,\r\n(Case WP.UseInventoryCost WHEN 0 Then ISNULL(WP.CatalogCost, 0) Else ISNULL(l.LicenseCost, 0) END) AS LicenseCost,\r\nWP.OSDRoleID, WP.TemplateID_FK, WP.AllowCollectionDeployment,wp.EnableScheduling,wp.AllowFileUpload,\r\nWP.EnableAlert, (Case ISNULL(WP.CheckFNMPLicensePosition, 0) WHEN 0 Then NULL Else WP.FUID END) AS FUID,\r\nWP.CheckFNMPAdvancedLicense, WP.FnmpLicenseScope, WP.CreatedOn, WP.UpdatedOn,\r\nWP.LinkPackageID_FK AS LinkedPackageID, ISNULL(DisableAppDetection,0) AS DisableAppDetection,\r\n(SELECT STUFF((SELECT ',' + CONVERT(NVARCHAR, PC.CategoryID) + '=' + CONVERT(NVARCHAR,\r\nISNULL(C.Secured, 0)) FROM WD_Package_Category PC INNER JOIN WD_Category C ON PC.CategoryID = C.CatID\r\nWHERE PC.PackageID = WP.PackageID FOR XML PATH('')), 1, 1, '')) AS Categories,\r\n(SELECT STUFF((SELECT '||' + VPP.PropertyName + ',' + VPP.PropertyValue + ',' + CONVERT(NVARCHAR, VPP.Visible) + ',' + VPP.Operator\r\nFROM dbo.WD_PackageProperty VPP WHERE VPP.PackageID_FK = WP.PackageID\r\nORDER BY VPP.Visible ASC FOR XML PATH('') ), 1, 2, '')) AS PackageProperties,\r\n(SELECT STUFF((SELECT '||' + VPP.PropertyName + ',' + VPP.PropertyValue + ',' + CONVERT(NVARCHAR, VPP.Visible) + ',' + VPP.Operator FROM dbo.WD_VPackageProperty VPP\r\nWHERE VPP.PackageID_FK = WP.PackageID ORDER BY VPP.Visible ASC FOR XML PATH('') ), 1, 2, '')) AS PackageVisibilities\r\nFROM WD_WebPackageLanguage AS wpl RIGHT OUTER JOIN    dbo.WD_WebPackages AS WP ON wpl.PackageID = WP.PackageID AND wpl.LanguageID = 0  LEFT OUTER JOIN  WD_License AS l ON WP.LicenseID_FK = l.LicenseID  left outer JOIN    dbo.WD_CatalogClassificationMapping AS ccm ON WP.PackageID = ccm.CatalogID  left outer join    dbo.WD_CatalogClassification As cclass on ccm.ClassificationID = cclass.ID\r\nWHERE  WP.Deleted IN (0, 1)  AND WP.PackageID Not IN ( Select Distinct PM.PackageID from WD_PackageMapper PM Where PM.MapperType in (2,3,4) )   AND WP.Type Not in (19,20,21,22,23) AND WP.PackageID Not IN (select Distinct packageID_fk from wd_Package_Deployment\r\nwhere PackageType In (19,20,21,22,23)) AND PackageVisible=1 AND PackageTitle like '%" + cc.getDataFromFile("ip_rq04_preferred") + "%'\r\norder by ClassificationSort,PackageTitle";
                SqlDataReader reader = HooksManager.connectAppPortal.ExecuteReader(CommandType.Text, query);
                while (reader.Read())
                {

                    string searchKeywordValue = reader["PackageTitle"].ToString();
                    sqlSearchKeywordList.Add(searchKeywordValue);
                    int classificationSort = (int)reader["ClassificationSort"];
                    sqlclassificationSortList.Add(classificationSort);

                }
                Thread.Sleep(2000);
                reader.Close();
            }
            else if (catalogType == "nonClassifed")
            {
                string query = "SELECT Distinct WP.PackageID, WP.CatID, WP.Deleted, WP.MemberOfGroup, WP.VisibleGroup, WP.LicenseDisable,\r\nISNULL(wpl.Title, WP.PackageTitle) AS PackageTitle, cclass.ClassificationName, cclass.ClassificationType,\r\nccm.ShowAlert, cclass.ImagePath AS ClassificationImagePath, case when cclass.ClassificationType = 0\r\nthen 0 when  cclass.ClassificationType = 1 then 2 else 1 end as ClassificationSort,\r\nISNULL(wpl.Description, WP.PackageDesc) AS PackageDesc, \r\nISNULL(wpl.BriefDescription, WP.BriefDescription) AS BriefDescription, WP.PackageVisible, WP.PackageRequest,\r\nWP.RunTime, WP.Reboots, WP.AppMethod, WP.OUInherit, WP.PackageRating, WP.PackageRank,  WP.vOUInherit,\r\nWP.GroupInherit, WP.ImagePath, WP.Type, WP.HasAlternate, WP.LicenseID_FK,l.PendingInstalls,\r\nl.LicenseCount - l.LicenseUsed AS LicenseRemaining, WP.Resource, WP.Site,   l.LicenseCount,\r\nl.LicenseUsed, l.Scope, l.Enforce, WP.ShowInventoryData, WP.AllowRental, WP.MaxRentalTime,\r\nWP.DisablePermanent, WP.AllowROB, WP.AllowRTP,  WP.AllowRTM, WP.AllowManual, WP.AllowUninstall,\r\nWP.AllowRepair, WP.VisibleShowMessage,WP.VisibleMessage, WP.ShowInventoryCostData,\r\n(Case WP.UseInventoryCost WHEN 0 Then ISNULL(WP.CatalogCost, 0) Else ISNULL(l.LicenseCost, 0) END) AS LicenseCost,\r\nWP.OSDRoleID, WP.TemplateID_FK, WP.AllowCollectionDeployment,wp.EnableScheduling,wp.AllowFileUpload,\r\nWP.EnableAlert, (Case ISNULL(WP.CheckFNMPLicensePosition, 0) WHEN 0 Then NULL Else WP.FUID END) AS FUID,\r\nWP.CheckFNMPAdvancedLicense, WP.FnmpLicenseScope, WP.CreatedOn, WP.UpdatedOn,\r\nWP.LinkPackageID_FK AS LinkedPackageID, ISNULL(DisableAppDetection,0) AS DisableAppDetection,\r\n(SELECT STUFF((SELECT ',' + CONVERT(NVARCHAR, PC.CategoryID) + '=' + CONVERT(NVARCHAR,\r\nISNULL(C.Secured, 0)) FROM WD_Package_Category PC INNER JOIN WD_Category C ON PC.CategoryID = C.CatID\r\nWHERE PC.PackageID = WP.PackageID FOR XML PATH('')), 1, 1, '')) AS Categories,\r\n(SELECT STUFF((SELECT '||' + VPP.PropertyName + ',' + VPP.PropertyValue + ',' + CONVERT(NVARCHAR, VPP.Visible) + ',' + VPP.Operator\r\nFROM dbo.WD_PackageProperty VPP WHERE VPP.PackageID_FK = WP.PackageID\r\nORDER BY VPP.Visible ASC FOR XML PATH('') ), 1, 2, '')) AS PackageProperties,\r\n(SELECT STUFF((SELECT '||' + VPP.PropertyName + ',' + VPP.PropertyValue + ',' + CONVERT(NVARCHAR, VPP.Visible) + ',' + VPP.Operator FROM dbo.WD_VPackageProperty VPP\r\nWHERE VPP.PackageID_FK = WP.PackageID ORDER BY VPP.Visible ASC FOR XML PATH('') ), 1, 2, '')) AS PackageVisibilities\r\nFROM WD_WebPackageLanguage AS wpl RIGHT OUTER JOIN    dbo.WD_WebPackages AS WP ON wpl.PackageID = WP.PackageID AND wpl.LanguageID = 0  LEFT OUTER JOIN  WD_License AS l ON WP.LicenseID_FK = l.LicenseID  left outer JOIN    dbo.WD_CatalogClassificationMapping AS ccm ON WP.PackageID = ccm.CatalogID  left outer join    dbo.WD_CatalogClassification As cclass on ccm.ClassificationID = cclass.ID\r\nWHERE  WP.Deleted IN (0, 1)  AND WP.PackageID Not IN ( Select Distinct PM.PackageID from WD_PackageMapper PM Where PM.MapperType in (2,3,4) )   AND WP.Type Not in (19,20,21,22,23) AND WP.PackageID Not IN (select Distinct packageID_fk from wd_Package_Deployment\r\nwhere PackageType In (19,20,21,22,23)) AND PackageVisible=1 AND PackageTitle like '%" + cc.getDataFromFile("ip_rq04__nonClassified") + "%'\r\norder by ClassificationSort,PackageTitle";
                SqlDataReader reader = HooksManager.connectAppPortal.ExecuteReader(CommandType.Text, query);
                while (reader.Read())
                {

                    string searchKeywordValue = reader["PackageTitle"].ToString();
                    sqlSearchKeywordList.Add(searchKeywordValue);
                    int classificationSort = (int)reader["ClassificationSort"];
                    sqlclassificationSortList.Add(classificationSort);

                }
                Thread.Sleep(2000);
                reader.Close();
            }
            else if (catalogType == "nonPreferred")
            {
                string query = "SELECT Distinct WP.PackageID, WP.CatID, WP.Deleted, WP.MemberOfGroup, WP.VisibleGroup, WP.LicenseDisable,\r\nISNULL(wpl.Title, WP.PackageTitle) AS PackageTitle, cclass.ClassificationName, cclass.ClassificationType,\r\nccm.ShowAlert, cclass.ImagePath AS ClassificationImagePath, case when cclass.ClassificationType = 0\r\nthen 0 when  cclass.ClassificationType = 1 then 2 else 1 end as ClassificationSort,\r\nISNULL(wpl.Description, WP.PackageDesc) AS PackageDesc, \r\nISNULL(wpl.BriefDescription, WP.BriefDescription) AS BriefDescription, WP.PackageVisible, WP.PackageRequest,\r\nWP.RunTime, WP.Reboots, WP.AppMethod, WP.OUInherit, WP.PackageRating, WP.PackageRank,  WP.vOUInherit,\r\nWP.GroupInherit, WP.ImagePath, WP.Type, WP.HasAlternate, WP.LicenseID_FK,l.PendingInstalls,\r\nl.LicenseCount - l.LicenseUsed AS LicenseRemaining, WP.Resource, WP.Site,   l.LicenseCount,\r\nl.LicenseUsed, l.Scope, l.Enforce, WP.ShowInventoryData, WP.AllowRental, WP.MaxRentalTime,\r\nWP.DisablePermanent, WP.AllowROB, WP.AllowRTP,  WP.AllowRTM, WP.AllowManual, WP.AllowUninstall,\r\nWP.AllowRepair, WP.VisibleShowMessage,WP.VisibleMessage, WP.ShowInventoryCostData,\r\n(Case WP.UseInventoryCost WHEN 0 Then ISNULL(WP.CatalogCost, 0) Else ISNULL(l.LicenseCost, 0) END) AS LicenseCost,\r\nWP.OSDRoleID, WP.TemplateID_FK, WP.AllowCollectionDeployment,wp.EnableScheduling,wp.AllowFileUpload,\r\nWP.EnableAlert, (Case ISNULL(WP.CheckFNMPLicensePosition, 0) WHEN 0 Then NULL Else WP.FUID END) AS FUID,\r\nWP.CheckFNMPAdvancedLicense, WP.FnmpLicenseScope, WP.CreatedOn, WP.UpdatedOn,\r\nWP.LinkPackageID_FK AS LinkedPackageID, ISNULL(DisableAppDetection,0) AS DisableAppDetection,\r\n(SELECT STUFF((SELECT ',' + CONVERT(NVARCHAR, PC.CategoryID) + '=' + CONVERT(NVARCHAR,\r\nISNULL(C.Secured, 0)) FROM WD_Package_Category PC INNER JOIN WD_Category C ON PC.CategoryID = C.CatID\r\nWHERE PC.PackageID = WP.PackageID FOR XML PATH('')), 1, 1, '')) AS Categories,\r\n(SELECT STUFF((SELECT '||' + VPP.PropertyName + ',' + VPP.PropertyValue + ',' + CONVERT(NVARCHAR, VPP.Visible) + ',' + VPP.Operator\r\nFROM dbo.WD_PackageProperty VPP WHERE VPP.PackageID_FK = WP.PackageID\r\nORDER BY VPP.Visible ASC FOR XML PATH('') ), 1, 2, '')) AS PackageProperties,\r\n(SELECT STUFF((SELECT '||' + VPP.PropertyName + ',' + VPP.PropertyValue + ',' + CONVERT(NVARCHAR, VPP.Visible) + ',' + VPP.Operator FROM dbo.WD_VPackageProperty VPP\r\nWHERE VPP.PackageID_FK = WP.PackageID ORDER BY VPP.Visible ASC FOR XML PATH('') ), 1, 2, '')) AS PackageVisibilities\r\nFROM WD_WebPackageLanguage AS wpl RIGHT OUTER JOIN    dbo.WD_WebPackages AS WP ON wpl.PackageID = WP.PackageID AND wpl.LanguageID = 0  LEFT OUTER JOIN  WD_License AS l ON WP.LicenseID_FK = l.LicenseID  left outer JOIN    dbo.WD_CatalogClassificationMapping AS ccm ON WP.PackageID = ccm.CatalogID  left outer join    dbo.WD_CatalogClassification As cclass on ccm.ClassificationID = cclass.ID\r\nWHERE  WP.Deleted IN (0, 1)  AND WP.PackageID Not IN ( Select Distinct PM.PackageID from WD_PackageMapper PM Where PM.MapperType in (2,3,4) )   AND WP.Type Not in (19,20,21,22,23) AND WP.PackageID Not IN (select Distinct packageID_fk from wd_Package_Deployment\r\nwhere PackageType In (19,20,21,22,23)) AND PackageVisible=1 AND PackageTitle like '%" + cc.getDataFromFile("ip_rq04_nonPreferred") + "%'\r\norder by ClassificationSort,PackageTitle";
                SqlDataReader reader = HooksManager.connectAppPortal.ExecuteReader(CommandType.Text, query);
                while (reader.Read())
                {
                    string searchKeywordValue = reader["PackageTitle"].ToString();
                    sqlSearchKeywordList.Add(searchKeywordValue);
                    int classificationSort = (int)reader["ClassificationSort"];
                    sqlclassificationSortList.Add(classificationSort);

                }
                Thread.Sleep(2000);
                reader.Close();
            }

            List<string> suggestionList = new List<string>();

            Thread.Sleep(6000);
            wait.UntilIsElementIsNotDisplayed(By.XPath("//img[@id='ajax-load-indicator']"));
            IList<IWebElement> suggestionValues = HooksManager.driver.FindElements(By.XPath("//ul[@role='listbox']/child::li"));
            if (suggestionValues.Count <= 10)
            {
                foreach (var value in suggestionValues)
                {
                    suggestionList.Add(value.Text.ToString().Trim());
                }
            }
            else
            {
                throw new Exception(string.Format("Auto Search Suggestions are not displayed"));
            }

            classificationList.Add("0");
            classificationList.Add("1");
            classificationList.Add("2");

            sqlclassificationSortList = sqlclassificationSortList.Distinct().ToList();
            for (int j = 0; j < sqlclassificationSortList.Count; j++)
            {
                if (!classificationList.Contains(sqlclassificationSortList[j].ToString()))
                {
                    throw new Exception(string.Format("The search suggestions does not consist of preferred,non-classified,non-preferred items"));
                }
            }

            sqlSearchKeywordList = sqlSearchKeywordList.OrderBy(x => x.ToString()).ToList();

            for (int i = 0; i < suggestionList.Count; i++)
            {
                if (!sqlSearchKeywordList.Contains(suggestionList[i]))
                {
                    throw new Exception(string.Format("List of Items not matched"));
                }               
            }
        }

        [Then(@"system should display the search suggestions on the preferred,non-classified,non-preferred items")]
        public void ThenSystemShouldDisplayTheSearchSuggestionsOnThePreferredNon_ClassifiedNon_PreferredItems()
        {
            List<int> sqlclassificationSortList = new List<int>();

            string query = "SELECT Distinct WP.PackageID, WP.CatID, WP.Deleted, WP.MemberOfGroup, WP.VisibleGroup, WP.LicenseDisable, ISNULL(wpl.Title, WP.PackageTitle) AS PackageTitle, cclass.ClassificationName, cclass.ClassificationType, ccm.ShowAlert, cclass.ImagePath AS ClassificationImagePath, case when cclass.ClassificationType = 0 then 0 when  cclass.ClassificationType = 1 then 2 else 1 end as ClassificationSort, ISNULL(wpl.Description, WP.PackageDesc) AS PackageDesc,  ISNULL(wpl.BriefDescription, WP.BriefDescription) AS BriefDescription, WP.PackageVisible, WP.PackageRequest, WP.RunTime, WP.Reboots, WP.AppMethod, WP.OUInherit, WP.PackageRating, WP.PackageRank,  WP.vOUInherit, WP.GroupInherit, WP.ImagePath, WP.Type, WP.HasAlternate, WP.LicenseID_FK,l.PendingInstalls, l.LicenseCount - l.LicenseUsed AS LicenseRemaining, WP.Resource, WP.Site,   l.LicenseCount, l.LicenseUsed, l.Scope, l.Enforce, WP.ShowInventoryData, WP.AllowRental, WP.MaxRentalTime, WP.DisablePermanent, WP.AllowROB, WP.AllowRTP,  WP.AllowRTM, WP.AllowManual, WP.AllowUninstall, WP.AllowRepair, WP.VisibleShowMessage,WP.VisibleMessage, WP.ShowInventoryCostData, (Case WP.UseInventoryCost WHEN 0 Then ISNULL(WP.CatalogCost, 0) Else ISNULL(l.LicenseCost, 0) END) AS LicenseCost, WP.OSDRoleID, WP.TemplateID_FK, WP.AllowCollectionDeployment,wp.EnableScheduling,wp.AllowFileUpload, WP.EnableAlert, (Case ISNULL(WP.CheckFNMPLicensePosition, 0) WHEN 0 Then NULL Else WP.FUID END) AS FUID, WP.CheckFNMPAdvancedLicense, WP.FnmpLicenseScope, WP.CreatedOn, WP.UpdatedOn, WP.LinkPackageID_FK AS LinkedPackageID, ISNULL(DisableAppDetection,0) AS DisableAppDetection, (SELECT STUFF((SELECT ',' + CONVERT(NVARCHAR, PC.CategoryID) + '=' + CONVERT(NVARCHAR, ISNULL(C.Secured, 0)) FROM WD_Package_Category PC INNER JOIN WD_Category C ON PC.CategoryID = C.CatID WHERE PC.PackageID = WP.PackageID FOR XML PATH('')), 1, 1, '')) AS Categories, (SELECT STUFF((SELECT '||' + VPP.PropertyName + ',' + VPP.PropertyValue + ',' + CONVERT(NVARCHAR, VPP.Visible) + ',' + VPP.Operator FROM dbo.WD_PackageProperty VPP WHERE VPP.PackageID_FK = WP.PackageID ORDER BY VPP.Visible ASC FOR XML PATH('') ), 1, 2, '')) AS PackageProperties, (SELECT STUFF((SELECT '||' + VPP.PropertyName + ',' + VPP.PropertyValue + ',' + CONVERT(NVARCHAR, VPP.Visible) + ',' + VPP.Operator FROM dbo.WD_VPackageProperty VPP WHERE VPP.PackageID_FK = WP.PackageID ORDER BY VPP.Visible ASC FOR XML PATH('') ), 1, 2, '')) AS PackageVisibilities FROM WD_WebPackageLanguage AS wpl RIGHT OUTER JOIN    dbo.WD_WebPackages AS WP ON wpl.PackageID = WP.PackageID AND wpl.LanguageID = 0  LEFT OUTER JOIN  WD_License AS l ON WP.LicenseID_FK = l.LicenseID  left outer JOIN    dbo.WD_CatalogClassificationMapping AS ccm ON WP.PackageID = ccm.CatalogID  left outer join    dbo.WD_CatalogClassification As cclass on ccm.ClassificationID = cclass.ID WHERE  WP.Deleted IN (0, 1)  AND WP.PackageID Not IN ( Select Distinct PM.PackageID from WD_PackageMapper PM Where PM.MapperType in (2,3,4) )   AND WP.Type Not in (19,20,21,22,23) AND WP.PackageID Not IN (select Distinct packageID_fk from wd_Package_Deployment where PackageType In (19,20,21,22,23)) AND PackageVisible=1 AND PackageTitle ='" + RQ03_AbilityToSearchUsingTheConfiguredSearchAttributesSteps.title + "' order by ClassificationSort,PackageTitle";
            SqlDataReader reader = HooksManager.connectAppPortal.ExecuteReader(CommandType.Text, query);
            while (reader.Read())
            {
                int classificationSort = (int)reader["ClassificationSort"];
                sqlclassificationSortList.Add(classificationSort);
            }
            reader.Close();

            classificationList.Add("0");
            classificationList.Add("1");
            classificationList.Add("2");

            sqlclassificationSortList = sqlclassificationSortList.Distinct().ToList();
            for (int j = 0; j < sqlclassificationSortList.Count; j++)
            {
                if (!classificationList.Contains(sqlclassificationSortList[j].ToString()))
                {
                    throw new Exception(string.Format("The search suggestions does not consist of preferred,non-classified,non-preferred items"));
                }
            }
        }

        [When(@"user click on the visibility button")]
        public void WhenUserClickOnTheVisibilityButton()
        {
            action.Click(appPortalPages.Tab_Visibility);
        }

        [Then(@"user should be able to set the ""([^""]*)"" and ""([^""]*)"" then save and close the settings")]
        public void ThenUserShouldBeAbleToSetTheAndThenSaveAndCloseTheSettings(string visibilityTerm, string binaryTerm)
        {
            string strIncludeExclude = "";
            if(visibilityTerm == "groupandou" && binaryTerm == "include")
            {
                strIncludeExclude = "Include Groups";
            }
            else if(visibilityTerm == "groupandou" && binaryTerm == "exclude")
            {
                strIncludeExclude = "Exclude Groups";
            }
            else if (visibilityTerm == "ad" && binaryTerm == "include")
            {
                strIncludeExclude = "Include Properties";
            }
            else if (visibilityTerm == "ad" && binaryTerm == "exclude")
            {
                strIncludeExclude = "Exclude Properties";
            }
            else if (visibilityTerm == "collections" && binaryTerm == "include")
            {
                strIncludeExclude = "Include Collections";
            }
            else if (visibilityTerm == "collections" && binaryTerm == "exclude")
            {
                strIncludeExclude = "Exclude Collections";
            }

            if (visibilityTerm == "ad")
            {
                /*if(binaryTerm =="include")
                {*/
                action.Click(appPortalPages.Tab_ADProperty);
                action.Click(appPortalPages.Btn_AddCondition);
                if (action.GetAttributeValue(appPortalPages.DropDown_City) == "City")
                {
                    action.Click(appPortalPages.DropDown_DownArrowCity);
                    IList<IWebElement> listWebElement = HooksManager.driver.FindElements(By.XPath("//div[@id='ctl00_cph1_Conditions1_ddlADAttributeClass_DropDown']//div[@class='rcbScroll rcbWidth']//li"));
                    Thread.Sleep(1000);
                    foreach (IWebElement element in listWebElement)
                    {
                        if (element.Text == "City")
                        {
                            element.Click();
                            break;
                        }
                    }
                }
                action.SendKeys(appPortalPages.TextBox_City, cc.getDataFromFile("visibilityCity"));

                if (action.GetAttributeValue(appPortalPages.DropDown_IncludeExclude) == strIncludeExclude)
                {
                    action.Click(appPortalPages.DropDown_IncludeExcludeDownArrow);
                    IList<IWebElement> listWebElement = HooksManager.driver.FindElements(By.XPath("//div[@id='ctl00_cph1_Conditions1_ddlPropDefaultCondition_DropDown']//div[@class='rcbScroll rcbWidth']//li"));
                    Thread.Sleep(1000);
                    foreach (IWebElement element in listWebElement)
                    {
                        if (element.Text == strIncludeExclude)
                        {
                            element.Click();
                            break;
                        }
                    }
                }
                action.Click(appPortalPages.Btn_SearchCity);
                action.Click(appPortalPages.CheckBox_ColumnSelectAD);
                action.Click(appPortalPages.Btn_SelectAD);
                action.Click(appPortalPages.Btn_Close);
                action.Click(appPortalPages.CheckBox_SelectSetADProperty);
                action.Click(appPortalPages.Btn_VisibilitySave);
                AssertionManager.ElementTextEquals(appPortalPages.Text_VisibilitySaveMessage, "Successfully updated visibility settings");
            }
            else if (visibilityTerm == "groupandou")
            {

            }
            else if (visibilityTerm == "collections")
            {

            }
        }

        [When(@"nonAdmin ""([^""]*)"" user is logged into the app portal")]
        public void WhenNonAdminUserIsLoggedIntoTheAppPortal(string userType)
        {
            // HooksManager.driver.Close();
            //rq04_Driver.Quit();
            string launchingURL = "";

            //=========================================================================
            Thread.Sleep(3000);
            String uname = "";
            // HooksManager.driverSetUp();

            if (cc.getDataFromFile("browser") == "chrome")
            {
                new WebDriverManager.DriverManager().SetUpDriver(new ChromeConfig());
                driverRQ04 = new ChromeDriver();
            }
            else if (cc.getDataFromFile("browser") == "edge")
            {
                new WebDriverManager.DriverManager().SetUpDriver(new EdgeConfig());
                driverRQ04 = new EdgeDriver();
            }
            else if (cc.getDataFromFile("browser") == "firefox")
            {
                new WebDriverManager.DriverManager().SetUpDriver(new FirefoxConfig());
                driverRQ04 = new FirefoxDriver();
            }
            else
            {
                Console.WriteLine("Not a valid browser name");
            }

            driverRQ04.Manage().Window.Maximize();
            driverRQ04.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(30);
            driverRQ04.Manage().Timeouts().PageLoad = TimeSpan.FromSeconds(30);


            // string launchingURL = cc.getDataFromFile("url");
            // driver.Navigate().GoToUrl("http://10.75.205.122/esd/");
            // HooksManager.driver.Navigate().GoToUrl(launchingURL);
            
            
            Thread.Sleep(3000);

            // Enter username
            if (userType == "assignedCity")
            {
                launchingURL = cc.getDataFromFile("url_AssignedCity");
                // uname = cc.getDataFromFile("nonadminusernamepune");
            }
            else if (userType == "nonAssignedCity")
            {
                launchingURL = cc.getDataFromFile("url_nonAssignedCity");
                //uname = cc.getDataFromFile("nonadminusernamenopune");
            }
            else if (userType.Equals("currentUser"))
            {
                launchingURL = cc.getDataFromFile("url_currentUser");
                // uname = cc.getDataFromFile("currentUserInImpersonateLogin");
            }
            driverRQ04.Navigate().GoToUrl(launchingURL);
            //HooksManager.inputSim.Keyboard.TextEntry(uname);
            //Thread.Sleep(1000);
            //// press Tab key 
            //HooksManager.inputSim.Keyboard.KeyPress(VirtualKeyCode.TAB);
            //Thread.Sleep(1000);
            //// Enter Password
            //string passwd = cc.getDataFromFile("pass");
            //HooksManager.inputSim.Keyboard.TextEntry(passwd);
            //Thread.Sleep(6000);
            //HooksManager.inputSim.Keyboard.KeyPress(VirtualKeyCode.RETURN);
            Thread.Sleep(30000);
            Assert.True(driverRQ04.Title.Contains("Flexera Software App Portal"));
            Console.WriteLine("Authentication Pop-up Login Completed through hooks");
        }

        [When(@"user navigate to the browser catalog tab Impersonation")]
        public void WhenUserNavigateToTheBrowserCatalogTabImpersonation()
        {
            // HooksManager.driver.SwitchTo().DefaultContent();
            driverRQ04.SwitchTo().DefaultContent();
            driverRQ04.FindElement(By.Id("Catalog"));
            // action.Click(appPortalPages.Tab_BrowseCatalog);
        }

        [When(@"user search by the title search term related data from the search text box Impersonation")]
        public void WhenUserSearchByTheTitleSearchTermRelatedDataFromTheSearchTextBoxImpersonation()
        {
            driverRQ04.FindElement(By.Id("searchCatalog")).SendKeys(RQ05_StepDefinitions.selectedTitle);
            driverRQ04.FindElement(By.Id("searchButton")).Click();
            // action.SendKeys(appPortalPages.TextBox_InputMainSearchCatalog, selectedTitle);
            // action.Click(appPortalPages.Button_Search);
        }



        /*[When(@"user search by the title search term related data from the search text box")]
        public void WhenUserSearchByTitleSearchTermRelatedDataFromTheSearchTextBox()
        {
            // HooksManager.driver.SwitchTo().DefaultContent();
            action.SendKeys(appPortalPages.TextBox_InputMainSearchCatalog, selectedTitle);
            action.Click(appPortalPages.Button_Search);
        }*/

        //[When(@"user navigate to the browser catalog tab(.*)")]
        //public void WhenUserNavigateToTheBrowserCatalogTab(int p0)
        //{
        //    driverRQ04.SwitchTo().DefaultContent();
        //    action.Click(appPortalPages.Tab_BrowseCatalog);
        //}

        [Then(@"system should display the search results for the given title search term data")]
        public void ThenSystemShouldDisplayTheSearchResultsForTheGivenTitleSearchTermData()
        {
            Thread.Sleep(5000);
            WebDriverWait wait1 = new WebDriverWait(driverRQ04, new TimeSpan(0, 0, 90));
            wait1.Until(ExpectedConditions.InvisibilityOfElementLocated(By.XPath("//img[@id='ajax-load-indicator']")));

            string searchtermresult = driverRQ04.FindElement(By.Id("resultsCategoryHeader")).Text.Replace('"', ' ').Trim();

            // wait1 = new WebDriverWait(driverRQ04, new TimeSpan(0, 0, 90));
            // wait1.Until(ExpectedConditions.InvisibilityOfElementLocated(By.XPath("//div//h1[contains(text(),'" + searchtermresult + "')]")));
            Assert.AreEqual(RQ05_StepDefinitions.selectedTitle, searchtermresult, "The search term result displayed is incorrect");
            driverRQ04.Quit();
        }

        [Then(@"system should not display the search results for the given title search term data Impersonation")]
        public void ThenSystemShouldNotDisplayTheSearchResultsForTheGivenTitleSearchTermDataImpersonation()
        {
            WebDriverWait wait1;
            string searchtermresult = ""; string resultCountMessage = "";
            bool flag = false;
            wait1 = new WebDriverWait(driverRQ04, new TimeSpan(0, 0, 90));
            wait1.Until(ExpectedConditions.InvisibilityOfElementLocated(By.XPath("//img[@id='ajax-load-indicator']")));

            searchtermresult = driverRQ04.FindElement(By.Id("resultsCategoryHeader")).Text.Replace('"', ' ').Trim();

            // wait1 = new WebDriverWait(driverRQ04, new TimeSpan(0, 0, 90));
            // wait1.Until(ExpectedConditions.InvisibilityOfElementLocated(By.XPath("//div//h1[contains(text(),'" + searchtermresult + "')]")));


            //IList<IWebElement> lstWebElement = HooksManager.driver.FindElements(By.XPath("//div[@class='cataloglistonscroll1']//div[@class='showcaseCardBody']/div"));
             IList<IWebElement> lstWebElement = driverRQ04.FindElements(By.XPath("//div[@class='cataloglistonscroll1']//div[@class='showcaseCardBody']/div"));

            foreach (IWebElement element in lstWebElement)
            {
                if (element.Text != "")
                {
                    lstString.Add(element.Text);
                }
            }

            if(lstString.Count > 0)
            {
                flag = lstString.Contains(RQ05_StepDefinitions.selectedTitle);
            }
            else
            {
                wait1 = new WebDriverWait(driverRQ04, new TimeSpan(0, 0, 90));
                wait1.Until(ExpectedConditions.InvisibilityOfElementLocated(By.XPath("//img[@id='ajax-load-indicator']")));

                searchtermresult = driverRQ04.FindElement(By.Id("resultsCategoryHeader")).Text.Replace('"', ' ').Trim();
                resultCountMessage = driverRQ04.FindElement(By.XPath("//div[@id='resultsCountHeader']/div[text()='There was no result for your search.']")).Text.Trim();

                // wait1 = new WebDriverWait(driverRQ04, new TimeSpan(0, 0, 90));
                // wait1.Until(ExpectedConditions.InvisibilityOfElementLocated(By.XPath("//div//h1[contains(text(),'" + searchtermresult + "')]")));
                Assert.AreEqual(RQ05_StepDefinitions.selectedTitle, searchtermresult, "The search term result displayed is incorrect");
                Assert.AreEqual("There was no result for your search.", resultCountMessage, "The result count message displayed is incorrect");
            }

            if(flag)
            {
                Assert.False(flag);
            }
            else
            {
                Console.WriteLine("Searched data not matching and testcase pass");
            }
            driverRQ04.Quit();
        }



        [When(@"user clicks on the search box from the app portal application for Impersonation")]
        public void WhenUserClicksOnTheSearchBoxFromTheAppPortalApplicationForImpersonation()
        {
            //action.Click(appPortalPages.TextBox_InputMainSearchCatalog);
            driverRQ04.FindElement(By.Id("searchCatalog")).Click();
        }

        [Then(@"system should display the list of search keyword suggestions based on the past history\(as the logged in ""([^""]*)"" past search keywords\)")]
        public void ThenSystemShouldDisplayTheListOfSearchKeywordSuggestionsBasedOnThePastHistoryAsTheLoggedInPastSearchKeywords(string userType)
        {
            if (userType == "impersonateUser")
            {
                string quer1 = "SELECT Top 10 SearchKeyword, MAX(searchdate) AS searchdate FROM [WD_UserSearchHistory] WHERE SearchDate > DATEADD(DAY, -90, GETDATE())  and UserName like '" + classcommon.getDataFromFile("impersonateUser") + "' GROUP BY SearchKeyword ORDER BY searchdate DESC";
                query = "SELECT Top 10 SearchKeyword, MAX(searchdate) AS searchDate FROM[WD_UserSearchHistory] WHERE SearchDate > DATEADD(DAY, -90, GETDATE())  and UserName like '%" + classcommon.getDataFromFile("impersonateUser") + "' GROUP BY SearchKeyword ORDER BY searchdate DESC";

            }
            SqlDataReader reader = HooksManager.connectAppPortal.ExecuteReader(CommandType.Text, query);

            while (reader.Read())
            {
                string searchKeywordValue = reader["SearchKeyword"].ToString();
                sqlSuggestionList.Add(searchKeywordValue);
            }
            sqlSuggestionList = sqlSuggestionList.OrderBy(x => x.ToString()).ToList();
            reader.Close();

            List<string> suggestionList = new List<string>();

            Thread.Sleep(6000);
            // wait.UntilIsElementIsNotDisplayed(By.XPath("//img[@id='ajax-load-indicator']"));
            IList<IWebElement> suggestionValues = driverRQ04.FindElements(By.XPath("//ul[@role='listbox']/child::li"));
            if (suggestionValues.Count <= 10)
            {
                foreach (var value in suggestionValues)
                {
                    suggestionList.Add(value.Text.ToString().Trim());
                }
            }
            else
            {
                throw new Exception(string.Format("Auto Search Suggestions are not displayed"));
            }

            Assert.AreEqual(sqlSuggestionList, suggestionList);
            driverRQ04.Quit();

        }
    }
}
