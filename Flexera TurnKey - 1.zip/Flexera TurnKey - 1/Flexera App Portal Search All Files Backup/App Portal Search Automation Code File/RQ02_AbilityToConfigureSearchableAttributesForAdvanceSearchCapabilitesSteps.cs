﻿using OpenQA.Selenium;
using AppPortalFlexera.Framework;
using AppPortalFlexera.Pages;

namespace AppPortalFlexera.StepDefinitions
{
    [Binding]
    public class RQ02_AbilityToConfigureSearchableAttributesForAdvanceSearchCapabilitySteps
    {
        AppPortalPages appPortalPages = new AppPortalPages();
        WaitManager wait = new WaitManager();
        ActionManager action = new ActionManager();
        
        [Then(@"the Admin should be able to view the different search terms \(Title, Brief Description, Full Description, Keyword\)")]
        public void ThenTheAdminShouldBeAbleToViewTheDifferentSearchTermsTitleBriefDescriptionFullDescriptionKeyword()
        {
            AssertionManager.Displayed(appPortalPages.CheckBox_TitleSearch);
            AssertionManager.Displayed(appPortalPages.CheckBox_BriefDescriptionSearch);
            AssertionManager.Displayed(appPortalPages.CheckBox_FullDescriptionSearch);
            AssertionManager.Displayed(appPortalPages.CheckBox_KeywordSearch);
        }

        [Then(@"the Admin should be able to view the different Enable advance search options\(Enable search by catalog classification,Enable search result display based on catalog classification,Enable fuzzy logic search,Enable search history based on user profile\) check boxes")]
        public void ThenTheAdminShouldBeAbleToViewTheDifferentEnableAdvanceSearchOptionsEnableSearchByCatalogClassificationEnableSearchResultDisplayBasedOnCatalogClassificationEnableFuzzyLogicSearchEnableSearchHistoryBasedOnUserProfileCheckBoxes()
        {
            AssertionManager.Displayed(appPortalPages.CheckBox_EnableAdvanceSearchOptions);
            AssertionManager.Displayed(appPortalPages.CheckBox_CatalogClassification);
            AssertionManager.Displayed(appPortalPages.CheckBox_DisplayCatalogClassification);
            AssertionManager.Displayed(appPortalPages.CheckBox_FuzzyLogicSearch);
            AssertionManager.Displayed(appPortalPages.CheckBox_HistorySearch);
        }

        [When(@"user ensure the ""([^""]*)"" search term checkbox\(is checked\)")]
        public void WhenUserEnsureTheSearchTermCheckboxIsChecked(string searchTermList)
        {
            List<string> searchTerm = searchTermList.Split(',').ToList();

            for (int i = 0; i < searchTerm.Count; i++)
            {

                if (searchTerm[i].ToString() == "Title")
                {
                    if (!appPortalPages.CheckBox_TitleSearch.Selected)
                    {
                        action.Click(appPortalPages.CheckBox_TitleSearch);
                    }
                }
                else if (searchTerm[i].Equals("Full description"))
                {
                    if (!appPortalPages.CheckBox_FullDescriptionSearch.Selected)
                    {
                        action.Click(appPortalPages.CheckBox_FullDescriptionSearch);
                    }
                }

                else if (searchTerm[i].Equals("Brief description"))
                {
                    if (!appPortalPages.CheckBox_BriefDescriptionSearch.Selected)
                    {
                        action.Click(appPortalPages.CheckBox_BriefDescriptionSearch);
                    }
                }

                else if (searchTerm[i].Equals("Keyword"))
                {
                    if (!appPortalPages.CheckBox_KeywordSearch.Selected)
                    {
                        action.Click(appPortalPages.CheckBox_KeywordSearch);
                    }
                }
                else if (searchTerm[i].Equals("Enable search by catalog classification"))
                {
                    if (!appPortalPages.CheckBox_CatalogClassification.Selected)
                    {
                        action.Click(appPortalPages.CheckBox_CatalogClassification);
                    }
                }
                else if (searchTerm[i].Equals("Enable search result display based on catalog classification"))
                {
                    if (!appPortalPages.CheckBox_DisplayCatalogClassification.Selected)
                    {
                        action.Click(appPortalPages.CheckBox_DisplayCatalogClassification);
                    }
                }
                else if (searchTerm[i].Equals("Enable fuzzy logic search"))
                {
                    if (!appPortalPages.CheckBox_FuzzyLogicSearch.Selected)
                    {
                        action.Click(appPortalPages.CheckBox_FuzzyLogicSearch);
                    }
                }
                else if (searchTerm[i].Equals("Enable search history based on user profile"))
                {
                    if (!appPortalPages.CheckBox_HistorySearch.Selected)
                    {
                        action.Click(appPortalPages.CheckBox_HistorySearch);
                    }
                }
                else if (searchTerm[i].Equals("Enable Catalog Classification"))
                {
                    if (!appPortalPages.CheckBox_EnableCatalogClassification.Selected)
                    {
                        action.Click(appPortalPages.CheckBox_EnableCatalogClassification);
                    }
                }
                else if (searchTerm[i].Equals("Enable Advance Search Option"))
                {
                    if (!appPortalPages.CheckBox_EnableAdvanceSearchOptions.Selected)
                    {
                        action.Click(appPortalPages.CheckBox_EnableAdvanceSearchOptions);
                    }
                }
            }

        }

        [Then(@"""([^""]*)"" search term checkbox should be displayed as checked")]
        public void ThenSearchTermCheckboxShouldBeDisplayedAsChecked(string searchTermList)
        {
            List<string> searchTerm = searchTermList.Split(',').ToList();

            for (int i = 0; i < searchTerm.Count; i++)
            {
                if (searchTerm[i].Equals("Title"))
                {
                    AssertionManager.Checked(appPortalPages.CheckBox_TitleSearch);
                }
                else if (searchTerm[i].Equals("Full description"))
                {
                    AssertionManager.Checked(appPortalPages.CheckBox_FullDescriptionSearch);
                }
                else if (searchTerm[i].Equals("Brief description"))
                {
                    AssertionManager.Checked(appPortalPages.CheckBox_BriefDescriptionSearch);
                }
                else if (searchTerm[i].Equals("Keyword"))
                {
                    AssertionManager.Checked(appPortalPages.CheckBox_KeywordSearch);
                }
                else if (searchTerm[i].Equals("Enable search by catalog classification"))
                {
                    AssertionManager.Checked(appPortalPages.CheckBox_CatalogClassification);
                }
                else if (searchTerm[i].Equals("Enable search result display based on catalog classification"))
                {
                    AssertionManager.Checked(appPortalPages.CheckBox_DisplayCatalogClassification);
                }
                else if (searchTerm[i].Equals("Enable fuzzy logic search"))
                {
                    AssertionManager.Checked(appPortalPages.CheckBox_FuzzyLogicSearch);
                }
                else if (searchTerm[i].Equals("Enable search history based on user profile"))
                {
                    AssertionManager.Checked(appPortalPages.CheckBox_HistorySearch);
                }
                else if (searchTerm[i].Equals("Enable Catalog Classification"))
                {
                    AssertionManager.Checked(appPortalPages.CheckBox_EnableCatalogClassification);
                }
            }

        }

        [When(@"user Uncheck the ""([^""]*)"" search term check box")]
        public void WhenUserUncheckTheSearchTermCheckBox(string basicSearchTermList)
        {
            string[] searchTerm = basicSearchTermList.Split(',');
            foreach (var term in searchTerm)
            {
                switch (term)
                {
                    case "Title":
                        if (appPortalPages.CheckBox_TitleSearch.Selected)
                        {
                            action.Click(appPortalPages.CheckBox_TitleSearch);
                        }
                        break;
                    case "Full description":
                        if (appPortalPages.CheckBox_FullDescriptionSearch.Selected)
                        {
                            action.Click(appPortalPages.CheckBox_FullDescriptionSearch);
                        }
                        break;
                    case "Brief description":
                        if (appPortalPages.CheckBox_BriefDescriptionSearch.Selected)
                        {
                            action.Click(appPortalPages.CheckBox_BriefDescriptionSearch);
                        }
                        break;
                    case "Keyword":
                        if (appPortalPages.CheckBox_KeywordSearch.Selected)
                        {
                            action.Click(appPortalPages.CheckBox_KeywordSearch);
                        }
                        break;
                    case "Enable search by catalog classification":
                        if (appPortalPages.CheckBox_CatalogClassification.Selected)
                        {
                            action.Click(appPortalPages.CheckBox_CatalogClassification);
                        }
                        break;
                    case "Enable search result display based on catalog classification":
                        if (appPortalPages.CheckBox_DisplayCatalogClassification.Selected)
                        {
                            action.Click(appPortalPages.CheckBox_DisplayCatalogClassification);
                        }
                        break;
                    case "Enable fuzzy logic search":
                        if (appPortalPages.CheckBox_FuzzyLogicSearch.Selected)
                        {
                            action.Click(appPortalPages.CheckBox_FuzzyLogicSearch);
                        }
                        break;
                    case "Enable search history based on user profile":
                        if (appPortalPages.CheckBox_HistorySearch.Selected)
                        {
                            action.Click(appPortalPages.CheckBox_HistorySearch);
                        }
                        break;
                    case "Enable Catalog Classification":
                        if (appPortalPages.CheckBox_EnableCatalogClassification.Selected)
                        {
                            action.Click(appPortalPages.CheckBox_EnableCatalogClassification);
                        }
                        break;
                   
                }
            }
        }

        [Then(@"""([^""]*)"" search terms check boxes should be displayed as unchecked")]
        public void ThenSearchTermsCheckBoxesShouldBeDisplayedAsUnchecked(string basicSearchTermList)
        {
            string[] searchTerm = basicSearchTermList.Split(',');
            foreach (var term in searchTerm)
            {
                switch(term)
                {
                    case "Title":
                        AssertionManager.UnChecked(appPortalPages.CheckBox_TitleSearch);
                        break;
                    case "Full description":
                        AssertionManager.UnChecked(appPortalPages.CheckBox_FullDescriptionSearch);
                        break;
                    case "Brief description":
                        AssertionManager.UnChecked(appPortalPages.CheckBox_BriefDescriptionSearch);
                        break;
                    case "Keyword":
                        AssertionManager.UnChecked(appPortalPages.CheckBox_KeywordSearch);
                        break;
                    case "Enable search by catalog classification":
                        AssertionManager.UnChecked(appPortalPages.CheckBox_CatalogClassification);
                        break;
                    case "Enable search result display based on catalog classification":
                        AssertionManager.UnChecked(appPortalPages.CheckBox_DisplayCatalogClassification);
                        break;
                    case "Enable fuzzy logic search":
                        AssertionManager.UnChecked(appPortalPages.CheckBox_FuzzyLogicSearch);
                        break;
                    case "Enable search history based on user profile":
                        AssertionManager.UnChecked(appPortalPages.CheckBox_HistorySearch);
                        break;
                    case "Enable Catalog Classification":
                        AssertionManager.UnChecked(appPortalPages.CheckBox_EnableCatalogClassification);
                        break;
                    
                }
            }
        }

        [Then(@"Admin user should be able to view the ""([^""]*)"" search terms check boxes as enable")]
        public void ThenAdminUserShouldBeAbleToViewTheSearchTermsCheckBoxesAsEnable(string basicSearchTermList)
        {
            //IJavaScriptExecutor jse = (IJavaScriptExecutor)HooksManager.HooksManager.driver;
            //jse.ExecuteScript("window.scrollBy(0,450)", "");

            string[] searchTerm = basicSearchTermList.Split(',');
            foreach (var term in searchTerm)
            {
                switch (term)
                {
                    //case "Title":
                    //    AssertionManager.Enabled(appPortalPages.CheckBox_TitleSearch);
                    //    break;
                    case "Full description":
                        AssertionManager.Enabled(appPortalPages.CheckBox_FullDescriptionSearch);
                        break;
                    case "Brief description":
                        AssertionManager.Enabled(appPortalPages.CheckBox_BriefDescriptionSearch);
                        break;
                    case "Keyword":
                        AssertionManager.Enabled(appPortalPages.CheckBox_KeywordSearch);
                        break;
                    case "Enable search by catalog classification":
                        wait.UntilElementIsEnabled(appPortalPages.CheckBox_CatalogClassification);
                        AssertionManager.Enabled(appPortalPages.CheckBox_CatalogClassification);
                        break;
                    case "Enable search result display based on catalog classification":
                        wait.UntilElementIsEnabled(appPortalPages.CheckBox_DisplayCatalogClassification);
                        AssertionManager.Enabled(appPortalPages.CheckBox_DisplayCatalogClassification);
                        break;
                    case "Enable fuzzy logic search":
                        wait.UntilElementIsEnabled(appPortalPages.CheckBox_FuzzyLogicSearch);
                        AssertionManager.Enabled(appPortalPages.CheckBox_FuzzyLogicSearch);
                        break;
                    case "Enable search history based on user profile":
                        wait.UntilElementIsEnabled(appPortalPages.CheckBox_HistorySearch);
                        AssertionManager.Enabled(appPortalPages.CheckBox_HistorySearch);
                        break;

                }
            }
        }

        [Then(@"Admin user should be able to view the ""([^""]*)"" search terms check boxes as disabled")]
        public void ThenAdminUserShouldBeAbleToViewTheSearchTermsCheckBoxesShouldAsDisabled(string searchTermList)
        {
            string[] searchTerm = searchTermList.Split(',');
            foreach (var term in searchTerm)
            {
                switch (term)
                {
                    case "Enable search by catalog classification":
                        AssertionManager.Disabled(appPortalPages.CheckBox_CatalogClassification);
                        break;
                    case "Enable search result display based on catalog classification":
                        AssertionManager.Disabled(appPortalPages.CheckBox_DisplayCatalogClassification);
                        break;
                    case " Enable fuzzy logic search":
                        AssertionManager.Disabled(appPortalPages.CheckBox_FuzzyLogicSearch);
                        break;
                    case "Enable search history based on user profile":
                        AssertionManager.Disabled(appPortalPages.CheckBox_HistorySearch);
                        break;

                }
            }
        }

        [When(@"user click on the save button,system display the save message")]
        public void WhenUserClickOnTheSaveButtonSystemDisplayTheSaveMessage()
        {
            action.Click(appPortalPages.Button_Save);
            wait.UntilIsElementIsNotDisplayed(By.XPath("//img[@id='ajax-load-indicator']"));
            wait.UntilElementTextIsDisplayed(appPortalPages.Text_SaveMessage);

            if (appPortalPages.Text_SaveMessage.Text != "Settings Saved.")
            {
                throw new Exception(string.Format("Saved message is not verified"));
            }
        }
    }
}
