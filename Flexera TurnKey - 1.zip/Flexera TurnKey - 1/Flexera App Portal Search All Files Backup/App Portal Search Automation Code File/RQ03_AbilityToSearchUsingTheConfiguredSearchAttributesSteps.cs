﻿using NUnit.Framework;
using OpenQA.Selenium;
using AppPortalFlexera.Framework;
using AppPortalFlexera.Pages;
using System.Data.SqlClient;
using System.Data;
using OpenQA.Selenium.Support.UI;
using Microsoft.AspNetCore.Http;
using static ICSharpCode.SharpZipLib.Zip.ExtendedUnixData;

namespace AppPortalFlexera.StepDefinitions
{
    [Binding]
    public class RQ03_AbilityToSearchUsingTheConfiguredSearchAttributesSteps
    {
        AppPortalPages appPortalPages = new AppPortalPages();
        ActionManager action = new ActionManager();
        WaitManager wait = new WaitManager();
        RQ05_StepDefinitions rq05_stepDefinitions = new RQ05_StepDefinitions();
        public static string searchtermresult = string.Empty;
        public static string title=string.Empty;
        public static string fullDescription = string.Empty;
        public static string briefDescription = string.Empty;
        public static string keyword = string.Empty;

        [When(@"user navigate to the browser catalog tab to perform the search")]
        public void WhenUserNavigateToTheBrowserCatalogTabToPerformTheSearch()
        {
            action.Click(appPortalPages.Button_Save);
            Thread.Sleep(800);
            //wait.UntilIsElementIsNotDisplayed(By.XPath("//img[@id='ajax-load-indicator']"));
            wait.UntilElementTextIsDisplayed(appPortalPages.Text_SaveMessage);
           
            if (appPortalPages.Text_SaveMessage.Text == "Settings Saved.")
            {
                HooksManager.driver.SwitchTo().DefaultContent();
                action.Click(appPortalPages.Tab_BrowseCatalog);
                Thread.Sleep(1000);
            }
            else
            {
                throw new Exception(string.Format("Saved message is not verified"));
            }
            
        }

        [When(@"user ensure all the search details from the database")]
        public void WhenUserEnsureAllTheSearchDetailsFromTheDatabase()
        {
            string query = "Select PackageTitle, BriefDescription, PackageDesc, KeyWord, * from WD_WebPackages left outer join WD_WebPackageKeyword on WD_WebPackages.PackageID = WD_WebPackageKeyword.PackageID_FK where PackageTitle != ' ' and PackageDesc != ' ' and BriefDescription != ' ' and  Deleted != 1 and PackageVisible=1";
            SqlDataReader reader = HooksManager.connectAppPortal.ExecuteReader(CommandType.Text, query);
            while (reader.Read())
            {
                title = reader["PackageTitle"].ToString();
                fullDescription = reader["PackageDesc"].ToString();
                briefDescription = reader["BriefDescription"].ToString();
                keyword = reader["KeyWord"].ToString();
                break;
            }
            reader.Close();
        }

        [When(@"user search by the data related to the ""([^""]*)"" from the app portal application")]
        public void WhenUserSearchByTheDataRelatedToTheFromTheAppPortalApplication(string searchTerm)
        {
            
            switch (searchTerm)
            {
                case "Title":
                    action.Clear(appPortalPages.TextBox_InputMainSearchCatalog);
                    action.SendKeys(appPortalPages.TextBox_InputMainSearchCatalog, title);
                    action.Click(appPortalPages.Button_Search);
                    break;
                case "Full description":
                    action.Clear(appPortalPages.TextBox_InputMainSearchCatalog);
                    action.SendKeys(appPortalPages.TextBox_InputMainSearchCatalog, fullDescription);
                    action.Click(appPortalPages.Button_Search);
                    break;
                case "Brief description":
                    action.Clear(appPortalPages.TextBox_InputMainSearchCatalog);
                    action.SendKeys(appPortalPages.TextBox_InputMainSearchCatalog, briefDescription);
                    action.Click(appPortalPages.Button_Search);
                    break;
                case "Keyword":
                    action.Clear(appPortalPages.TextBox_InputMainSearchCatalog);
                    action.SendKeys(appPortalPages.TextBox_InputMainSearchCatalog, keyword);
                    action.Click(appPortalPages.Button_Search);
                    break;               
            }
        }

        [When(@"user search by the data related to the ""([^""]*)"" from the app portal application,by hitting the enter button from the keyboard")]
        public void WhenUserSearchByTheDataRelatedToTheFromTheAppPortalApplicationByHittingTheEnterButtonFromTheKeyboard(string searchTerm)
        {
            switch (searchTerm)
            {
                case "Title":
                    action.Clear(appPortalPages.TextBox_InputMainSearchCatalog);
                    action.SendKeys(appPortalPages.TextBox_InputMainSearchCatalog, title);
                    action.Click(appPortalPages.Button_Search);
                    // action.SendKeys(appPortalPages.TextBox_InputMainSearchCatalog, Keys.Enter);                   
                    break;
                case "Full description":
                    action.Clear(appPortalPages.TextBox_InputMainSearchCatalog);
                    action.SendKeys(appPortalPages.TextBox_InputMainSearchCatalog, fullDescription);
                    action.Click(appPortalPages.Button_Search);
                    // action.SendKeys(appPortalPages.TextBox_InputMainSearchCatalog, Keys.Enter);
                    break;
                case "Brief description":
                    action.Clear(appPortalPages.TextBox_InputMainSearchCatalog);
                    action.SendKeys(appPortalPages.TextBox_InputMainSearchCatalog, briefDescription);
                    Thread.Sleep(5000);
                    action.Click(appPortalPages.Button_Search);
                    // action.SendKeys(appPortalPages.TextBox_InputMainSearchCatalog, Keys.Enter);
                    break;
                case "Keyword":
                    action.Clear(appPortalPages.TextBox_InputMainSearchCatalog);
                    action.SendKeys(appPortalPages.TextBox_InputMainSearchCatalog, keyword);
                    Thread.Sleep(15000);
                    action.Click(appPortalPages.Button_Search);
                    // action.SendKeys(appPortalPages.TextBox_InputMainSearchCatalog, Keys.Enter);
                    break;
            }
            Thread.Sleep(5000);
        }

        [Then(@"system should display the search results according to the data provided ""([^""]*)"" in the search text box")]
        public void ThenSystemShouldDisplayTheSearchResultsAccordingToTheDataProvidedInTheSearchTextBox(string searchTermResult)
        {
            Thread.Sleep(6000);
            wait.UntilIsElementIsNotDisplayed(By.XPath("//img[@id='ajax-load-indicator']"));
            searchtermresult = appPortalPages.Text_SearchResult.Text.Replace('"', ' ').Trim();
            wait.UntilIsElementIsDisplayed(By.XPath("//div//h1[contains(text(),'" + searchtermresult + "')]"));

            if (searchTermResult == "Title")
            {
                Assert.AreEqual(title, searchtermresult, "The search term result displayed is incorrect");
                appPortalPages.VerifySearchResult();
            }
            else if (searchTermResult == "Full description")
            {
                Assert.AreEqual(fullDescription, searchtermresult, "The search term result displayed is incorrect");
                appPortalPages.VerifySearchResult();
            }
            else if (searchTermResult == "Brief description")
            {
                Assert.AreEqual(briefDescription, searchtermresult, "The search term result displayed is incorrect");
                appPortalPages.VerifySearchResult();
            }
            else if (searchTermResult == "Keyword")
            {
                Assert.AreEqual(keyword, searchtermresult, "The search term result displayed is incorrect");
                appPortalPages.VerifySearchResult();
            }
        }

        [Then(@"system should not display the search results for the data provided ""([^""]*)"" search term")]
        public void ThenSystemShouldNotDisplayTheSearchResultsForTheDataProvidedSearchTerm(string searchTerm)
        {
            //Thread.Sleep(4000);
            wait.UntilIsElementIsNotDisplayed(By.XPath("//img[@id='ajax-load-indicator']"));
            searchtermresult = appPortalPages.Text_SearchResult.Text.Replace('"', ' ').Trim();
            wait.UntilIsElementIsDisplayed(By.XPath("//div//h1[contains(text(),'" + searchtermresult + "')]"));

            switch (searchTerm)
            {
                case "Title":
                    Assert.AreEqual(title, searchtermresult, "The search term result displayed is incorrect");
                    rq05_stepDefinitions.verifyTheSearchResult();
                    // AssertionManager.ElementTextEquals(appPortalPages.Text_NoSearchResult, "There was no result for your search.");
                    break;
                case "Full description":
                    Assert.AreEqual(fullDescription, searchtermresult, "The search term result displayed is incorrect");
                    rq05_stepDefinitions.verifyTheSearchResult();
                    // AssertionManager.ElementTextEquals(appPortalPages.Text_NoSearchResult, "There was no result for your search.");
                    break;
                case "Brief description":
                    Assert.AreEqual(briefDescription, searchtermresult, "The search term result displayed is incorrect");
                    rq05_stepDefinitions.verifyTheSearchResult();
                    // AssertionManager.ElementTextEquals(appPortalPages.Text_NoSearchResult, "There was no result for your search.");
                    break;
                case "Keyword":
                    Assert.AreEqual(keyword, searchtermresult, "The search term result displayed is incorrect");
                    rq05_stepDefinitions.verifyTheSearchResult();
                    // AssertionManager.ElementTextEquals(appPortalPages.Text_NoSearchResult, "There was no result for your search.");
                    break;
            }
        }

        [When(@"user search by the typo/misspelled data ""([^""]*)"" related to the ""([^""]*)"" from the app portal application")]
        public void WhenUserSearchByTheTypoMisspelledDataRelatedToTheFromTheAppPortalApplication(string misspelledData, string searchTerm)
        {
            Thread.Sleep(2000);
            wait.UntilIsElementIsNotDisplayed(By.XPath("//img[@id='ajax-load-indicator']"));
            switch (searchTerm)
            {
                case "Title":
                    action.Clear(appPortalPages.TextBox_InputMainSearchCatalog);
                    action.SendKeys(appPortalPages.TextBox_InputMainSearchCatalog, misspelledData);
                    action.Click(appPortalPages.Button_Search);
                    break;
                case "Full description":
                    action.Clear(appPortalPages.TextBox_InputMainSearchCatalog);
                    action.SendKeys(appPortalPages.TextBox_InputMainSearchCatalog, misspelledData);
                    action.Click(appPortalPages.Button_Search);
                    break;
                case "Brief description":
                    action.Clear(appPortalPages.TextBox_InputMainSearchCatalog);
                    action.SendKeys(appPortalPages.TextBox_InputMainSearchCatalog, misspelledData);
                    action.Click(appPortalPages.Button_Search);
                    break;
                case "Keyword":
                    action.Clear(appPortalPages.TextBox_InputMainSearchCatalog);
                    action.SendKeys(appPortalPages.TextBox_InputMainSearchCatalog,misspelledData);
                    action.Click(appPortalPages.Button_Search);
                    break;
                
            }
            Thread.Sleep(TimeSpan.FromSeconds(60));
        }

        [Then(@"system should display the search results according to the typo/misspelled data ""([^""]*)"" provided in ""([^""]*)"" search text box")]
        public void ThenSystemShouldDisplayTheSearchResultsAccordingToTheTypoMisspelledDataProvidedInSearchTextBox(string searchTermData, string searchTerm)
        {
            Thread.Sleep(5000);
            wait.UntilIsElementIsNotDisplayed(By.XPath("//img[@id='ajax-load-indicator']"));
            Thread.Sleep(1000);
            searchtermresult = appPortalPages.Text_SearchResult.Text.Replace('"', ' ').Trim();
            wait.UntilIsElementIsDisplayed(By.XPath("//div//h1[contains(text(),'" + searchtermresult + "')]"));

            if (searchTerm == "Title")
            {
                Assert.AreEqual(searchTermData, searchtermresult, "The search term result displayed is incorrect");
                appPortalPages.VerifySearchResult();
            }
            else if (searchTerm == "Full description")
            {
                Assert.AreEqual(searchTermData, searchtermresult, "The search term result displayed is incorrect");
                appPortalPages.VerifySearchResult();
            }
            else if (searchTerm == "Brief description")
            {
                Assert.AreEqual(searchTermData, searchtermresult, "The search term result displayed is incorrect");
                appPortalPages.VerifySearchResult();
            }
            else if (searchTerm == "Keyword")
            {
                Assert.AreEqual(searchTermData, searchtermresult, "The search term result displayed is incorrect");
                appPortalPages.VerifySearchResult();
            }
        }

        [When(@"user navigate to the Catalog Classification page\(Admin >> Site Management >> Settings >> Web Site >> Catalog Classification page\)")]
        public void WhenUserNavigateToTheCatalogClassificationPageAdminSiteManagementSettingsWebSiteCatalogClassificationPage()
        {
            if(appPortalPages.Tab_CatalogClassification.Enabled)
            {
                action.Click(appPortalPages.Tab_CatalogClassification);
            }
        }

        [Then(@"user should be able to see the ""([^""]*)"" option selected in the sort dropdown box")]
        public void ThenUserShouldBeAbleToSeeTheOptionSelectedInTheSortDropdownBox(string sortByInDropDownBoxValue)
        {
            SelectElement status = new SelectElement(appPortalPages.DropDownBox_SortBy);
            IWebElement selected = status.SelectedOption;
            Console.Write("Selected value in Drop Down Box is" + selected.Text);
            if (selected.Text == sortByInDropDownBoxValue)
            {
                Console.WriteLine("Drop Down Selected Value Verified");
            }
            else
            {
                throw new Exception(string.Format("Drop Down Selected Value not Verified"));
            }

        }

        [Then(@"all the search results should be automatically sorted by the catalog classification")]
        public void ThenAllTheSearchResultsShouldBeAutomaticallySortedByTheCatalogClassification()
        {
            var alphabetical = true;
            List<string> actualLinkList = new List<string>();
            List<string> newSortedList = new List<string>();

            for (int i = 0; i <= 2; i++)
            {
                actualLinkList.Clear();
                newSortedList.Clear();
                IList<IWebElement> listWebElement = HooksManager.driver.FindElements(By.XPath("//div[@class='cataloglistonscroll" + i + "']//div[@class='showcaseCardTitle']"));
                
                foreach (var item in listWebElement)
                {
                    actualLinkList.Add(item.Text);
                    newSortedList.Add(item.Text);
                }

                newSortedList.Sort();

                if (actualLinkList.Count > 1)
                {
                    alphabetical = true;
                    for (int j = 0; j < actualLinkList.Count - 1; j++)
                    {
                        if (actualLinkList[j] != newSortedList[j])
                        {
                            alphabetical = false;
                            break;
                        }
                    }
                }
                if (alphabetical == false)
                {
                    throw new Exception(string.Format("Displayed data is not in sorted order"));
                }
            }
        }

        [Then(@"user should not be able to see the ""([^""]*)"" option selected in the sort dropdown box")]
        public void ThenUserShouldNotBeAbleToSeeTheOptionSelectedInTheSortDropdownBox(string sortByInDropDownBoxValue)
        {
            SelectElement status = new SelectElement(appPortalPages.DropDownBox_SortBy);
            IWebElement selected = status.SelectedOption;
            Console.Write("Selected value in Drop Down Box is" + selected.Text);
            if (selected.Text != sortByInDropDownBoxValue)
            {
                Console.WriteLine("Drop Down Selected Value Verified");
            }
            else
            {
                throw new Exception(string.Format("Drop Down Selected Value not Verified"));
            }
        }

        [Then(@"system should not display the search results for the ""([^""]*)"" data provided for ""([^""]*)"" search term")]
        public void ThenSystemShouldNotDisplayTheSearchResultsForTheDataProvidedForSearchTerm(string searchData, string searchTerm)
        {
            Thread.Sleep(6000);
            wait.UntilIsElementIsNotDisplayed(By.XPath("//img[@id='ajax-load-indicator']"));
            searchtermresult = appPortalPages.Text_SearchResult.Text.Replace('"', ' ').Trim();
            wait.UntilIsElementIsDisplayed(By.XPath("//div//h1[contains(text(),'" + searchtermresult + "')]"));

            switch (searchTerm)
            {
                case "Title":
                    Assert.AreEqual(searchData, searchtermresult, "The search term result displayed is incorrect");
                    AssertionManager.ElementTextEquals(appPortalPages.Text_NoSearchResult, "There was no result for your search.");
                    break;
                case "Full description":
                    Assert.AreEqual(searchData, searchtermresult, "The search term result displayed is incorrect");
                    AssertionManager.ElementTextEquals(appPortalPages.Text_NoSearchResult, "There was no result for your search.");
                    break;
                case "Brief description":
                    Assert.AreEqual(searchData, searchtermresult, "The search term result displayed is incorrect");
                    AssertionManager.ElementTextEquals(appPortalPages.Text_NoSearchResult, "There was no result for your search.");
                    break;
                case "Keyword":
                    Assert.AreEqual(searchData, searchtermresult, "The search term result displayed is incorrect");
                    AssertionManager.ElementTextEquals(appPortalPages.Text_NoSearchResult, "There was no result for your search.");
                    break;
            }
        }
    }
}
