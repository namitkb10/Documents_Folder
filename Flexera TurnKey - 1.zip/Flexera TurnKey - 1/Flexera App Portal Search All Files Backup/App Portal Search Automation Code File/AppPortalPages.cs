﻿using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using AppPortalFlexera.Framework;


namespace AppPortalFlexera.Pages
{
    public class AppPortalPages
    {       
        public AppPortalPages()
        {
            PageFactory.InitElements(HooksManager.driver, this);
        }

        [FindsBy(How = How.XPath, Using = "//span[contains(text(),'Welcome App Portal')]")]
        public IWebElement Text_WelcomeTitle { get; set; }

        [FindsBy(How = How.Id, Using = "Admin")]
        public IWebElement Tab_Admin { get; set; }

        [FindsBy(How = How.Id, Using = "tnSiteConfiguration")]
        public IWebElement Tab_SiteManagement { get; set; }

        [FindsBy(How = How.Id, Using = "nodeSettings")]
        public IWebElement Tab_Settings { get; set; }

        [FindsBy(How = How.Id, Using = "RadPanelItem121")]
        public IWebElement Tab_WebSite { get; set; }

        //CatalogBehaviourPage
        [FindsBy(How = How.XPath, Using = "//span[contains(text(),'Catalog Behavior')]")]
        public IWebElement Tab_CatalogBehaviour { get; set; }

        [FindsBy(How = How.Id, Using = "RAD_SPLITTER_PANE_EXT_CONTENT_ctl00_cph1_topPane")]
        public IWebElement Tab_Frame { get; set; }

        [FindsBy(How = How.Id, Using = "ctl00_cph1_TitleSearch")]
        public IWebElement CheckBox_TitleSearch { get; set; }

        [FindsBy(How = How.Id, Using = "ctl00_cph1_BriefDescriptionSearch")]
        public IWebElement CheckBox_BriefDescriptionSearch { get; set; }

        [FindsBy(How = How.Id, Using = "ctl00_cph1_FullDescriptionSearch")]
        public IWebElement CheckBox_FullDescriptionSearch { get; set; }

        [FindsBy(How = How.Id, Using = "ctl00_cph1_KeywordSearch")]
        public IWebElement CheckBox_KeywordSearch { get; set; }

        [FindsBy(How = How.Id, Using = "ctl00_cph1_AdvancSearch")]
        public IWebElement CheckBox_EnableAdvanceSearchOptions { get; set; }

        [FindsBy(How = How.Id, Using = "ctl00_cph1_CatalogClassification")]
        public IWebElement CheckBox_CatalogClassification { get; set; }

        [FindsBy(How = How.Id, Using = "ctl00_cph1_DisplayCatalogClassification")]
        public IWebElement CheckBox_DisplayCatalogClassification { get; set; }

        [FindsBy(How = How.Id, Using = "ctl00_cph1_FuzzySearch")]
        public IWebElement CheckBox_FuzzyLogicSearch { get; set; }

        [FindsBy(How = How.Id, Using = "ctl00_cph1_HistorySearch")]
        public IWebElement CheckBox_HistorySearch { get; set; }

        [FindsBy(How = How.ClassName, Using = "rtbIn")]
        public IWebElement Button_Save { get; set; }



        [FindsBy(How = How.XPath, Using = "//span[text()='Settings Saved.']")]
        public IWebElement Text_SaveMessage { get; set; }

        //BrowserCatalogPage
        [FindsBy(How = How.Id, Using = "Catalog")]
        public IWebElement Tab_BrowseCatalog { get; set; }

        [FindsBy(How = How.Id, Using = "searchCatalog")]
        public IWebElement TextBox_InputMainSearchCatalog { get; set; }

        [FindsBy(How = How.Id, Using = "searchButton")]
        public IWebElement Button_Search { get; set; }

        [FindsBy(How = How.Id, Using = "resultsCategoryHeader")]
        public IWebElement Text_SearchResult { get; set; }

        [FindsBy(How = How.Id, Using = "resultsCountHeader")]
        public IWebElement Count_Result { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[contains(text(),'There was no result for your search.')]")]
        public IWebElement Text_NoSearchResult { get; set; }

        [FindsBy(How = How.Id, Using = "ddlResultsSort")]
        public IWebElement DropDownBox_SortBy { get; set; }

        //CatalogClassification
        [FindsBy(How = How.XPath, Using = "//span[text()='Catalog Classification']")]
        public IWebElement Tab_CatalogClassification { get; set; }

        [FindsBy(How = How.Id, Using = "ctl00_cph1_EnableCatalogClassification")]
        public IWebElement CheckBox_EnableCatalogClassification { get; set; }
      
        //CatalogManagement
        [FindsBy(How = How.XPath, Using = "//span[contains(text(),'Catalog Management')]")]
        public IWebElement Tab_CatalogManagement { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[contains(text(),'Current Catalog Items')]")]
        public IWebElement Tab_CurrentCatalogItems { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[contains(text(),'View All Items')]")]
        public IWebElement Tab_ViewAllItems { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@id='ctl00_cph1_Grid1_GridData']//tbody/tr")]
        public IList<IWebElement> TableRows_ItemDetails { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@id='ctl00_cph1_Grid1_GridData']//tbody/tr/td")]
        public IList<IWebElement> TableColumns_ItemDetails { get; set; }

        //GeneralPopupPage
        [FindsBy(How = How.XPath, Using = "//div[@id='ctl00_cph1_mpGeneral']//input[@id='ctl00_cph1_cbGlobalVisible']")]
        public IWebElement CheckBox_IsEnabled { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[text()='Archive']")]
        public IWebElement Button_Archive { get; set; }

        [FindsBy(How = How.XPath, Using = "//a[@class='rwCloseButton']")]
        public IWebElement Button_Close { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[text()='Successfully updated catalog item.']")]
        public IWebElement Text_PopupSaveMessage { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[text()='Successfully removed request.']")]
        public IWebElement Text_ArchiveMessage { get; set; }

        [FindsBy(How = How.Id, Using = "ctl00_cph1_cboCategory_Arrow")]
        public IWebElement DropDown_Category { get; set; }
        
        [FindsBy(How = How.XPath, Using = "//div//table[@class='rwTable rwShadow']//tr//td/iframe")]
        public IWebElement Tab_GeneralFrame { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@class='cataloglistonscroll1']//div[@class='showcaseCardBody']/div")]
        public IWebElement Card_ShowCaseCardBody { get; set; }

        // Impersonation
        // ========================================================================================================

        /*[FindsBy(How = How.XPath, Using = "//span[contains(text(),'Site Management')]")]
        public IWebElement Tab_SiteManagement { get; set; }*/

        [FindsBy(How = How.Id, Using = "tnSiteConfiguration")]
        public IWebElement Expandable_SiteManagement { get; set; }

        [FindsBy(How = How.XPath, Using = "//a[@id='tnActiveDirectory']//span[text()='Active Directory']")]
        public IWebElement Expandable_ActiveDirectory { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[@class='rpText' and text()='User Impersonation']")]
        public IWebElement Expandable_UserImpersonation { get; set; }

        [FindsBy(How = How.XPath, Using = "//a[@class='rtbWrap']")]
        public IWebElement Btn_ImpersonationNew { get; set; }

        [FindsBy(How = How.XPath, Using = "//td[@class='rwWindowContent rwExternalContent']/iframe")]
        public IWebElement Window_NewImpersonation { get; set; }

        [FindsBy(How = How.XPath, Using = "//input[@id='ctl00_cph1_txtImpersonatedAccount']")]
        public IWebElement TextBox_AccountToImpersonate { get; set; }

        [FindsBy(How = How.Id, Using = "ctl00_cph1_SecurityGroupPicker1_ddlDomain_Arrow")]
        public IWebElement DropDownArrow_SelectAccountToImpersonateClick { get; set; }

        [FindsBy(How = How.Id, Using = "ctl00_cph1_SecurityGroupPicker1_txtSearchValue")]
        public IWebElement TextBox_CurrentUserImpersonate { get; set; }


        [FindsBy(How = How.Id, Using = "ctl00_cph1_SecurityGroupPicker1_btnSearch")]
        public IWebElement Btn_SearchImpersonation { get; set; }



        [FindsBy(How = How.XPath, Using = "//li[@id='ctl00_cph1_SecurityGroupPicker1_lbSearchResults_i0']/span[@class='rlbText']")]
        public IWebElement TextArea_SearchResultArea { get; set; }

        [FindsBy(How = How.Id, Using = "ctl00_cph1_btnAdd_input")]
        public IWebElement Btn_AddSelectedAccount { get; set; }

        [FindsBy(How = How.Id, Using = "ctl00_cph1_rlbImpersonate_i0")]
        public IWebElement TextArea_ImpersonatedAccountArea { get; set; }


        [FindsBy(How = How.XPath, Using = "//span[@class='rtbText' and text()='Save']")]
        public IWebElement Btn_ImpersonationSave { get; set; }



        // [FindsBy(How = How.XPath, Using = "//a[@class='rwCloseButton']")]
        [FindsBy(How = How.XPath, Using = "//tbody//ul[@class='rwControlButtons']//a[@class='rwCloseButton']")]
        public IWebElement Btn_crossCloseButton { get; set; }

        //[FindsBy(How = How.XPath, Using = "//div//table[@class='rwTable rwShadow']//tr//td/iframe")]
        //public IWebElement Tab_GeneralFrame { get; set; }

        //[FindsBy(How = How.XPath, Using = "//div//table[@class='rwTable rwShadow']//tr//td/iframe")]
        //public IWebElement Tab_GeneralFrame { get; set; }

        // Catalog Items settings
        //=========================================================================================================
        [FindsBy(How = How.XPath, Using = "//span[@class='rtbText' and text()='Save']")]
        public IWebElement Btn_GlobalSave { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[text()='Successfully updated catalog item.']")]
        public IWebElement Text_CatalogSaveMessage { get; set; }

        [FindsBy(How = How.Id, Using = "ctl00_cph1_cboCategory_Input")]
        public IWebElement DropDown_CategoryGeneralSettingsPage { get; set; }

        [FindsBy(How = How.Id, Using = "ctl00_cph1_cboCategory_Arrow")]
        public IWebElement DropDownArrow_CategoryGeneralSettingsPage { get; set; }


        

        [FindsBy(How = How.XPath, Using = "//span[@class='rtsTxt' and text()='Visibility']")]
        public IWebElement Tab_Visibility { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[@class='rtsTxt' and contains(text(), 'AD Property')]")]
        public IWebElement Tab_ADProperty { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@id='ctl00_cph1_Conditions1_viewProperty']//span[@class='rtbText' and text()='Add Condition']")]
        public IWebElement Btn_AddCondition { get; set; }

        [FindsBy(How = How.Id, Using = "ctl00_cph1_Conditions1_ddlADAttributeClass_Input")]
        public IWebElement DropDown_City { get; set; }

        [FindsBy(How = How.Id, Using = "ctl00_cph1_Conditions1_ddlADAttributeClass_Arrow")]
        public IWebElement DropDown_DownArrowCity { get; set; }

        

        [FindsBy(How = How.Id, Using = "ctl00_cph1_Conditions1_txtADAttribValue")]
        public IWebElement TextBox_City { get; set; }

        [FindsBy(How = How.Id, Using = "ctl00_cph1_Conditions1_ddlPropDefaultCondition_Input")]
        public IWebElement DropDown_IncludeExclude { get; set; }

        [FindsBy(How = How.Id, Using = "ctl00_cph1_Conditions1_ddlPropDefaultCondition_Arrow")]
        public IWebElement DropDown_IncludeExcludeDownArrow { get; set; }

        [FindsBy(How = How.Id, Using = "ctl00_cph1_Conditions1_btnADAttribSearch")]
        public IWebElement Btn_SearchCity { get; set; }

        [FindsBy(How = How.Id, Using = "ctl00_cph1_Conditions1_gvPropertySearch_ctl00_ctl04_columnSelectCheckBox")]
        public IWebElement CheckBox_ColumnSelectAD { get; set; }

        [FindsBy(How = How.XPath, Using = "//a[@class='rtbWrap']//span[@class='rtbText' and text()='Select']")]
        public IWebElement Btn_SelectAD { get; set; }

        [FindsBy(How = How.XPath, Using = "//a[@class='rtCloseButton']")]
        public IWebElement Btn_Close { get; set; }

        [FindsBy(How = How.Id, Using = "ctl00_cph1_Conditions1_gvCurrentProperty_ctl00_ctl04_CurrentPropertySelectSelectCheckBox")]
        public IWebElement CheckBox_SelectSetADProperty { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[@class='rtbIn']/span [text()='Save']")]
        public IWebElement Btn_VisibilitySave { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[text()='Successfully updated visibility settings']")]
        public IWebElement Text_VisibilitySaveMessage { get; set; }

        // Below Element verify required or not
        [FindsBy(How = How.Id, Using = "searchCatalog")]
        public IWebElement _textBoxInputMainSearchCatalog { get; set; }

        [FindsBy(How = How.Id, Using = "searchButton")]
        public IWebElement _btnSearchButton { get; set; }

        [FindsBy(How = How.Id, Using = "//input[@id='ctl00_cph1_Conditions1_ddlADAttributeClass_Input']")]
        public IWebElement _ddlSelectedCity { get; set; }

        [FindsBy(How = How.Id, Using = "ctl00_cph1_Conditions1_txtADAttribValue")]
        public IWebElement _inputCityTextBox { get; set; }

        [FindsBy(How = How.XPath, Using = "//a[@class='rtCloseButton']")]
        public IWebElement _buttonClose { get; set; }
        //=========================================================================================================
        // Group OU
        [FindsBy(How = How.XPath, Using = "//span[@class='rtsTxt' and contains(text(), 'Group and OU')]")]
        public IWebElement Tab_GroupAndOU { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@id='ctl00_cph1_Conditions1_ddlDomain_DropDown']//ul[@class='rcbList']/li")]
        public IWebElement DropDown_AppPortal { get; set; }

        [FindsBy(How = How.Id, Using = "ctl00_cph1_Conditions1_ddlDomain_Arrow")]
        public IWebElement DropDownArrow_AppPortal { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@id='ctl00_cph1_Conditions1_ddlObjectClass_DropDown']//ul[@class='rcbList']/li")]
        public IWebElement DropDown_SearchGroupsOUs { get; set; }

        [FindsBy(How = How.Id, Using = "ctl00_cph1_Conditions1_ddlObjectClass_Arrow")]
        public IWebElement DropDownArrow_SearchGroupsOUs { get; set; }

        [FindsBy(How = How.Id, Using = "ctl00_cph1_Conditions1_txtSearchValue")]
        public IWebElement TextBox_EnterGroupOR_OU { get; set; }

        [FindsBy(How = How.Id, Using = "ctl00_cph1_Conditions1_btnSearch")]
        public IWebElement Btn_Search { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@id='ctl00_cph1_Conditions1_ddlADDefaultCondition_DropDown']//ul[@class='rcbList']/li")]
        public IWebElement DropDown_IncludeExcludeGroup { get; set; }

        [FindsBy(How = How.Id, Using = "ctl00_cph1_Conditions1_ddlADDefaultCondition_Input")]
        public IWebElement DropDownArrow_IncludeExcludeGroup { get; set; }


        /*[FindsBy(How = How.Id, Using = "ctl00_cph1_Conditions1_ddlADDefaultCondition_Input")]
        public IWebElement CheckBox_IncludeExcludeGroup { get; set; }*/

        [FindsBy(How = How.Id, Using = "//div[@id='RadToolTipWrapper_ctl00_cph1_Conditions1_ttADBrowse']//a[@class='rtCloseButton']")]
        public IWebElement Btn_CloseGroupAndOU_PopUpPage { get; set; }

        /*[FindsBy(How = How.Id, Using = "ctl00_cph1_Conditions1_ddlADDefaultCondition_Input")]
        public IWebElement CheckBox_IncludeExcludeGroup { get; set; }*/

        //=========================================================================================================
        // Collections
        [FindsBy(How = How.XPath, Using = "//span[@class='rtsTxt' and contains(text(), 'Collections')]")]
        public IWebElement Tab_Collections { get; set; }

        [FindsBy(How = How.Id, Using = "ctl00_cph1_Conditions1_txtCollectionName")]
        public IWebElement TextBox_EnterCollectionsName { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@id='ctl00_cph1_Conditions1_ddlCollDefaultCondition_DropDown']//ul[@class='rcbList']/li")]
        public IWebElement DropDown_IncludeExcludeCollections { get; set; }

        [FindsBy(How = How.Id, Using = "ctl00_cph1_Conditions1_ddlCollDefaultCondition_Arrow")]
        public IWebElement DropDownArrow_IncludeExcludeCollections { get; set; }

        /*[FindsBy(How = How.Id, Using = "ctl00_cph1_Conditions1_ddlADDefaultCondition_Input")]
        public IWebElement CheckBox_IncludeExcludeGroup { get; set; }*/

        [FindsBy(How = How.Id, Using = "//div[@id='RadToolTipWrapper_ctl00_cph1_Conditions1_ttCollection']//a[@class='rtCloseButton']")]
        public IWebElement Btn_CloseCollections_PopUpPage { get; set; }

        /*[FindsBy(How = How.Id, Using = "ctl00_cph1_Conditions1_ddlADDefaultCondition_Input")]
        public IWebElement CheckBox_IncludeExcludeGroup { get; set; }*/

        //=========================================================================================================
        public void VerifySearchResult()
        {
            var resultTxt = Count_Result.Text;
            string[] strArr = resultTxt.Split(" ");
            if (Int32.Parse(strArr[0]) > 0)
            {
                Console.WriteLine("Entered Text have" + Int32.Parse(strArr[0]) + " matched data");
            }
            else
            {
                throw new Exception(string.Format("Entered Text doesn't have matched data"));
            }
        }
    }
}
