package selenium_Scenario_Based_Question;

import org.openqa.selenium.io.Zip;

public class Zip_Unzip_File {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// Zip.unzip(source, outputDir);

	}

}
