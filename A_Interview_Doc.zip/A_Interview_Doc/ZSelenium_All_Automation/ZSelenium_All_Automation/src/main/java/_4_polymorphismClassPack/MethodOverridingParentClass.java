package _4_polymorphismClassPack;

public class MethodOverridingParentClass {
	
	// https://www.softwaretestingmaterial.com/polymorphism-in-java/
	
	public void myMethod(){
		System.out.println("I am a method from Parent Class");
	}
}
