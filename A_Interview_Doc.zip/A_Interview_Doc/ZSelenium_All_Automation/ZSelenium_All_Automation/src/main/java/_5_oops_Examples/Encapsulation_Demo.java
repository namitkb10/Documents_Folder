package _5_oops_Examples;

public class Encapsulation_Demo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
