package _3_inheritancePack;

public class Employee {
	// https://www.softwaretestingmaterial.com/inheritance-in-java/
	String name="Namit";
}
