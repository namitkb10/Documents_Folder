package yet_To_Do;

public class DemoSite {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		// http://www.tutorialsninja.com/demo/
	}
}
