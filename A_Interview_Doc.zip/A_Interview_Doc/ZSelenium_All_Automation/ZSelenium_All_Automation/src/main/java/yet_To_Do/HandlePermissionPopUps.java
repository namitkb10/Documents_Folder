package yet_To_Do;

import org.openqa.selenium.WebDriver;

public class HandlePermissionPopUps {

	static WebDriver driver;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// How to handle Permission Pop-ups using Selenium WebDriver | Selenium |
		// https://www.youtube.com/watch?v=deKXbbIHD4w
		// Browser based pop-up, it is not HTML based pop-up
		
		//driver.switchTo().alert().
	}
}
