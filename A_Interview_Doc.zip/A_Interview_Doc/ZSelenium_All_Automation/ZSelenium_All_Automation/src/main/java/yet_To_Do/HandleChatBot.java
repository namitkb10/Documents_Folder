package yet_To_Do;

public class HandleChatBot {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// How To Handle Chat Bot in Selenium WebDriver using Java
		// https://www.youtube.com/watch?v=Gu9PPDbHTGo
	}

}
