package yet_To_Do;

import org.openqa.selenium.remote.DesiredCapabilities;

public class Others_Program_Example {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// https://www.youtube.com/watch?v=lvIXXilkw60
		
		// 
		
		// https://www.softwaretestingo.com/nagarro-interview-questions/
		
		// DesiredCapabilities? Write down the syntax?
		// ChromeOptions options = new ChromeOptions(); --- setCapabilities and addArguements?
		// 
		// What is Chrome Options Class?
		// Example:

//		Below example shows a way to open Chrome browser in maximized mode using ChromeOptions class. We need to pass an instance of ChromeOptions class to the web driver initialization.
//		
//		ChromeOptions options = new ChromeOptions()
//		options.addArgument("start-maximized");
//		ChromeDriver driver = new ChromeDriver(options);
//		Below are the list of available and most commonly used arguments for ChromeOptions class
//		
//		start-maximized: Opens Chrome in maximize mode
//		incognito: Opens Chrome in incognito mode
//		headless: Opens Chrome in headless mode
//		disable-extensions: Disables existing extensions on Chrome browser
//		disable-popup-blocking: Disables pop-ups displayed on Chrome browser
//		make-default-browser: Makes Chrome default browser
//		version: Prints chrome browser version
//		disable-infobars: Prevents Chrome from displaying the notification 'Chrome is being controlled by automated software
		
		
		
		
		
		// Write Back to Excel Page --- Write data (with Columns) using Apache POI? - Done
		// It possible to write back to configuration.properties file
		
		// How many Meetings in Agile?
		// 5
		// Ans: Sprint planning, Daily Scrum, Sprint Review, Sprint retrospective, Backlog Refinement/Grooming
		
		
	}
}
