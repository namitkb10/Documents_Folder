package selenium_Small_Concepts;

public class Different_Way_Of_Executions {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// Using Surefire plug-in in POM.xml file
 	}
}
