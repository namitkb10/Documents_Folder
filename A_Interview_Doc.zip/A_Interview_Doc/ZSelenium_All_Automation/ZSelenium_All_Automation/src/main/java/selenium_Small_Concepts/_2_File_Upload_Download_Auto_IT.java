package selenium_Small_Concepts;

public class _2_File_Upload_Download_Auto_IT {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
}
