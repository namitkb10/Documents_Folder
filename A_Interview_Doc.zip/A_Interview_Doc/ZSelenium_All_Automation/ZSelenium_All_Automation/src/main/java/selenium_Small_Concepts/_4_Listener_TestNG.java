package selenium_Small_Concepts;

import org.testng.ITestListener;

public class _4_Listener_TestNG implements ITestListener {

}
