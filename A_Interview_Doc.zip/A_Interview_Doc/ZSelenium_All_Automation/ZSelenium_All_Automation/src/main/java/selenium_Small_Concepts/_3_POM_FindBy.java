package selenium_Small_Concepts;

public class _3_POM_FindBy {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
