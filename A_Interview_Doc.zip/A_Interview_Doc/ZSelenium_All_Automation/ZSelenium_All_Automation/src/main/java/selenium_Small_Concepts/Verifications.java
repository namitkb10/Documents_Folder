package selenium_Small_Concepts;

public class Verifications {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		// Code Available in TestNG Folder
		// Code Available in TestNG Folder
		// Code Available in TestNG Folder
		// Code Available in TestNG Folder
		// Code Available in TestNG Folder
	}
}
