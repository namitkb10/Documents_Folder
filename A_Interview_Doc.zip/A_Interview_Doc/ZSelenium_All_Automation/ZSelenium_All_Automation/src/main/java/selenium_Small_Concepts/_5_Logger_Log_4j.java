package selenium_Small_Concepts;

public class _5_Logger_Log_4j {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
}
