package xPath_Axes;

public class Namespace {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
