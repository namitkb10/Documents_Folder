package xPath_Axes;

public class Attribute {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
}
