package xPath_Functions;

public class Using_OR_and_AND {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
