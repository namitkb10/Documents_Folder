package xPath_Functions;

public class Xpath_Ends_with {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
