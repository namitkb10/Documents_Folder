package xPath_Functions;

public class Basic_XPath {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
