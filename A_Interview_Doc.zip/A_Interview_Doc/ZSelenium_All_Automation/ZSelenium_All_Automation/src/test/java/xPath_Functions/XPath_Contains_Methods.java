package xPath_Functions;

public class XPath_Contains_Methods {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
