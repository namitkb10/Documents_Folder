package xPath_Functions;

public class XPath_Text_Function {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
