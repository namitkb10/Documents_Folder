package xPath_Functions;

public class XPath_normalize_space_method {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
