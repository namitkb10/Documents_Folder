package java_Concepts;

public class Ex_Diff_Bw_Static_and_Final_Variable {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		// https://www.youtube.com/watch?v=YV9vFQKUBHw
		
		// Final 
		
		// Cannot assign value twice to Final variable
		// Final method cannot override method in child class
		// If we make any class final, we cannot extend it to child class
		
		// Static
		
		// Static key word in java used for memory management purpose only (Ex: College Name)
		// Static will assign memory only once (static variable value can change)
		// A static method belongs to the class rather than the object of a class
		// A static method can be invoked without the need for creating an instance of a class
	}
}
