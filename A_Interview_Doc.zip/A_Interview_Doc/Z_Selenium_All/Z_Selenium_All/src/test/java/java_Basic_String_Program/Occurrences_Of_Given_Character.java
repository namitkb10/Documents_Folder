package java_Basic_String_Program;

public class Occurrences_Of_Given_Character {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String s = "Java is java again java again";
        char c = 'a';
        
        int count = s.length() - s.replace("a", "").length();
        
        System.out.println("Character a Repeats: " + count + " Times");
	}
}
