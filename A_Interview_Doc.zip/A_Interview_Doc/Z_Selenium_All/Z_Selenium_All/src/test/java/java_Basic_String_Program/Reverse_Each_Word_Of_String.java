package java_Basic_String_Program;

public class Reverse_Each_Word_Of_String {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str = "Namit Kumar Burnwal";
		System.out.println("Entered String is: " + str);
		String revStr = ""; String dStr = ""; 
		String[] strArr = str.split(" ");
		
		int count = strArr.length;
		for (int i = 0; i < count; i++) {
			dStr="";
			for (int j = strArr[i].length()-1; j >= 0 ; j--) {
				dStr = dStr + strArr[i].charAt(j);
			}
			revStr =revStr + dStr +  " ";
		}
		System.out.println("Reverse Of Entered String is: " + revStr);
	}
}
