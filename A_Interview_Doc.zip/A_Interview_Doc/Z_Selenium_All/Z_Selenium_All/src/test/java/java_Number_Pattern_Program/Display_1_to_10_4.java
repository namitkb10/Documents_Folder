package java_Number_Pattern_Program;

public class Display_1_to_10_4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
}
