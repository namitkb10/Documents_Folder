package java_Number_Pattern_Program;

public class Descending_Order_Pattern_3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num = 4;
		for (int i = 0; i < num; i++) {
			for (int j = 0; j < args.length; j++) {
				System.out.println("Not Implemented Yet");
			}
		}
	}
}

// Expectation (Reverse Of Below)

//1
//2 3
//4 5 6
//7 8 9 10

// Expected

//7 8 9 10
//4 5 6
//2 3
//1
