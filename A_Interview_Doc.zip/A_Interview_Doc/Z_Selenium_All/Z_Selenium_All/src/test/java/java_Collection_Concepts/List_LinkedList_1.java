package java_Collection_Concepts;

import java.util.LinkedList;

public class List_LinkedList_1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LinkedList lnkLst = new LinkedList();
		lnkLst.add("Namit");
		lnkLst.add(10);
		lnkLst.add('K');
		lnkLst.add(15.5);
		lnkLst.add("Bengaluru");
		
		System.out.println("Linked List: " + lnkLst);
		
		//lnkLst.
		
	}
}
