package java_Collection_Concepts;

public class Queue_PriorityQueue_2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
