package java_Collection_Concepts;

public class Arrays {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int[] num = new int[5];
		num[0] = 10;
		num[1] = 20;
		num[2] = 30;
		num[3] = 40;
		num[4] = 50;
		// ==============================================================================
		
		// Display 1st Array
		for (int i = 0; i < num.length; i++) {
			System.out.print(num[i] + " ");
		}
		
		int[] newNum = new int[num.length];
		
		// Copy one Array data into another Array and display
		for (int j = 0; j < newNum.length; j++) {
			newNum[j]=num[j];
		}
		
		System.out.println();
		System.out.println();
		
		// Display New Array
		for (int k = 0; k < newNum.length; k++) {
			System.out.print(newNum[k] + " ");
		}
		
		System.out.println();
		System.out.println();
		
		// Copy elements of num[] to c[]
        int c[] = num.clone();
        
     // Display New Array
     	for (int l = 0; l < newNum.length; l++) {
     		System.out.print(c[l] + " ");
     	}
	}
}
