package string_Program;

import java.util.Scanner;

public class PalindromeString_1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scn = new Scanner(System.in);
		System.out.print("Enter String: ");
		String oStr = scn.next();
		String rStr = "";
		scn.close();
		
		//String[] strArr = str.split("");
		
		for (int i = oStr.length()-1; i >= 0 ; i--) {
			rStr = rStr + oStr.charAt(i);
		}
		if(oStr.equalsIgnoreCase(rStr))
		{
			System.out.println("Entered String is Palindrome");
		}
		else
		{
			System.out.println("Entered String is not Palindrome");
		}
	}
}
