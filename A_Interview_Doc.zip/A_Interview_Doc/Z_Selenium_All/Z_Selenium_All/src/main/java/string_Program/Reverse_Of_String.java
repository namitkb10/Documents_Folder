package string_Program;

// import java.net.InetAddress;
// import java.net.UnknownHostException;

public class Reverse_Of_String {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("1st Method");
		String str1 = "Namit";
		String revStr1 ="";
		for (int i = str1.length()-1; i >= 0 ; i--) {
			revStr1 = revStr1 + str1.charAt(i);
		}
		System.out.println("Reverse Of 1st String: " + revStr1);
		
		System.out.println("==========================================================");
		System.out.println("2nd Method");
		
		String str2="Kumar"; String revStr2 = "";
		String[] strArr = str2.split("");
		
		for (int i = strArr.length-1; i >=0 ; i--) {
			revStr2 = revStr2 + strArr[i];
		}
		
		System.out.println("Reverse Of 2nd String: " + revStr2);
		System.out.println("==========================================================");
		System.out.println("3rd Method");
		
		String str3="Barnwal"; String revStr3 = "";
		char[] ch = str3.toCharArray();
		
		for (int i = ch.length-1; i >=0 ; i--) {
			revStr3 = revStr3 + ch[i];
		}
		
		System.out.println("Reverse Of 3rd String: " + revStr3);
		System.out.println("==========================================================");
		System.out.println("4th Method");
		
		String str4="Divya";
		char[] ch1 = str4.toCharArray();
		System.out.print("Reverse Of 4th String: ");
		for (int i = ch1.length-1; i >=0 ; i--) {
			System.out.print(ch1[i]);
		}
		System.out.println();
		System.out.println("==========================================================");
		System.out.println("5th Method");
		
		String str5="Jyoti";
		StringBuilder sbd = new StringBuilder(str5);
				
		System.out.println("Reverse Of 5th String: " + sbd.reverse());
		System.out.println("==========================================================");
		System.out.println("6th Method");
		
		String str6="Bharti";
		StringBuffer sbf = new StringBuffer(str6);
				
		System.out.println("Reverse Of 6th String: " + sbf.reverse());
		System.out.println("==========================================================");
		
	}
}