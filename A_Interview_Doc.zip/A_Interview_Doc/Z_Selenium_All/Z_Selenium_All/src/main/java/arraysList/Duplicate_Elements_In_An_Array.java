package arraysList;

public class Duplicate_Elements_In_An_Array {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String[] strArr = {"Java", ".Net", "Python", "Ruby", "Java", "Ruby", "Asp", "Java", "Jsp"};
		
		for (int i = 0; i < strArr.length-1; i++) {
			for (int j = i+1; j < strArr.length; j++) {
				if(strArr[i].equals(strArr[j]) && (i != j))
				{
					System.out.println(strArr[j]);
				}
			}
		}
	}
}
