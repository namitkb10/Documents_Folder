package arraysList;

import java.util.ArrayList;

public class Array_Count_Duplicate {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] intArr = {4, 3, 2, 3, 1, 2, 5, 7, 3, 5, 2};
		ArrayList<Integer> intArrList = new ArrayList<Integer>();
		int count =1;
		
		for (int i = 0; i < intArr.length; i++) {
			count =1;
			if(!intArrList.contains(intArr[i]))
			{
				intArrList.add(intArr[i]);
				for (int j = i+1; j < intArr.length; j++) {
					if(intArr[i]==intArr[j])
					{
						count++;
					}
				}
				System.out.println(intArr[i] + " --- repeats --- " + count  + " --- times");;
			}
		}
	}
}