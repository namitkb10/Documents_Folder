package hashMap;

import java.util.HashMap;
import java.util.Map;

public class Nested_HashMap {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Map<String, HashMap<Integer, String>> outerHashMap = new HashMap<String, HashMap<Integer, String>>();
		
		HashMap<Integer, String> innerHashMap1 = new HashMap<Integer, String>();
		HashMap<Integer, String> innerHashMap2 = new HashMap<Integer, String>();
		HashMap<Integer, String> innerHashMap3 = new HashMap<Integer, String>();
		
		innerHashMap1.put(11, "Apple");
		innerHashMap1.put(12, "Banana");
		innerHashMap1.put(13, "Orange");
		innerHashMap2.put(21, "Potato");
		innerHashMap2.put(22, "Onion");
		innerHashMap2.put(23, "Tomato");
		innerHashMap3.put(31, "Tea");
		innerHashMap3.put(32, "Coffee");
		innerHashMap3.put(33, "Paneer");
		
		outerHashMap.put("Fruits", innerHashMap1);
		outerHashMap.put("Vegetables", innerHashMap2);
		outerHashMap.put("Milk", innerHashMap3);
		
		// HashMap hm = outerHashMap.get(�Fruits�);

		// String name = (String) hm.get(1);
		
		
//		hMap.put(1, "Fruit");
//		hMap.put(2, "Kumar");
//		hMap.put(3, "Burnwal");
//		hMap.put(4, "Divya");
//		hMap.put(5, "Jyoti");
//		hMap.put(6, "Bharti");
//		
////		for (Integer i : hMap.keySet()) {
////		      System.out.print(i + " ");
////		    }
////		System.out.println();
//		
//		for (Map.Entry m : hMap.entrySet()) {
//			System.out.println(m.getKey()+" --- "+m.getValue());
//			
//		}
	}
}
